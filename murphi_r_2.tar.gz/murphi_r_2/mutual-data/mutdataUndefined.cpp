/******************************
  Program "mutdataUndefined.m" compiled by "Caching Murphi Release 5.4.9.1"

  Murphi Last Compiled date: "Apr  6 2018"
 ******************************/

/********************
  Parameter
 ********************/
#define MURPHI_VERSION "Caching Murphi Release 5.4.9.1"
#define MURPHI_DATE "Apr  6 2018"
#define PROTOCOL_NAME "mutdataUndefined"
#define BITS_IN_WORLD 56
#define ALIGN

/********************
  Include
 ********************/
#include "mu_prolog.hpp"

/********************
  Decl declaration
 ********************/

class mu_1_state: public mu__byte
{
 public:
  inline int operator=(int val) { return value(val); };
  inline int operator=(const mu_1_state& val) { return value(val.value()); };
  static const char *values[];
  friend ostream& operator<< (ostream& s, mu_1_state& val)
  {
    if (val.defined())
      return ( s << mu_1_state::values[ int(val) - 1] );
    else return ( s << "Undefined" );
  };

  mu_1_state (const char *name, int os): mu__byte(1, 4, 3, name, os) {};
  mu_1_state (void): mu__byte(1, 4, 3) {};
  mu_1_state (int val): mu__byte(1, 4, 3, "Parameter or function result.", 0)
  {
     operator=(val);
  };
  const char * Name() { return values[ value() -1]; };
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);

	 static int number_r;
	virtual void random()
	{
		if (defined())
		{
			int random_number = random1(number_r);
			value(random_number + 1);
		}
	}

	virtual void printTitle()
	{
		csvFile<<name<<",";
	}
	virtual void printValue()
	{
		if (defined())
		{
			csvFile<<values[ value() -1]<<",";
		}
		else
		{
			csvFile<<"Undefined,";
		}
	}
  virtual void MultisetSort() {};
  void print_statistic() {};
  virtual void print()
  {
    if (defined())
      cout << name << ":" << values[ value() -1] << '\n';
    else
      cout << name << ":Undefined\n";
  };
};

const char *mu_1_state::values[] = {"I","T","C","E",NULL };


int mu_1_state::number_r = 4;
/*** end of enum declaration ***/
mu_1_state mu_1_state_undefined_var;

class mu_1_DATA: public mu__byte
{
 public:
  inline int operator=(int val) { return value(val); };
  inline int operator=(const mu_1_DATA& val){ return value(val.value());};
  inline operator int() const { return value(); };
  static const char *values[];
  friend ostream& operator<< (ostream& s, mu_1_DATA& val)
    {
      if (val.defined())
	return ( s << mu_1_DATA::values[ int(val) - 5 ] );
      else
	return ( s << "Undefined" );
    };

  mu_1_DATA (const char *name, int os): mu__byte(5, 6, 2, name, os) {};
  mu_1_DATA (void): mu__byte(5, 6, 2) {};
  mu_1_DATA (int val): mu__byte(5, 6, 2, "Parameter or function result.", 0)
    { operator=(val); };
  const char * Name() { return values[ value() -5]; };
  virtual void print()
    {
      if (defined()) cout << name << ':' << values[ value() - 5] << '\n';
      else cout << name << ":Undefined\n";
    };
  void print_statistic() {};
friend int CompareWeight(mu_1_DATA& a, mu_1_DATA& b)
{
  if (!a.defined() && b.defined())
    return -1;
  else if (a.defined() && !b.defined())
    return 1;
  else
    return 0;
}
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);

	 static int number_r_s;
	virtual void random()
	{
		if (defined())
		{
			int random_number = random1(number_r_s);
			value(random_number + 5);
		}
	}

	virtual void printTitle()
	{
		csvFile<<name<<",";
	}
	virtual void printValue()
	{
		if (defined())
		{
			csvFile<<values[ value() -5]<<",";
		}
		else
		{
			csvFile<<"Undefined,";
		}
	}
};
const char *mu_1_DATA::values[] =
  { "DATA_1","DATA_2",NULL };


int mu_1_DATA::number_r_s = 2;
/*** end scalarset declaration ***/
mu_1_DATA mu_1_DATA_undefined_var;

class mu_1_status
{
 public:
  char *name;
  char longname[BUFFER_SIZE/4];
  void set_self_2( const char *n, const char *n2, int os);
  void set_self_ar( const char *n, const char *n2, int os);
  void set_self(const char *n, int os);
  mu_1_state mu_st;
  mu_1_DATA mu_data;
  mu_1_status ( const char *n, int os ) { set_self(n,os); };
  mu_1_status ( void ) {};

  virtual ~mu_1_status(); 
friend int CompareWeight(mu_1_status& a, mu_1_status& b)
  {
    int w;
    w = CompareWeight(a.mu_st, b.mu_st);
    if (w!=0) return w;
    w = CompareWeight(a.mu_data, b.mu_data);
    if (w!=0) return w;
  return 0;
}
friend int Compare(mu_1_status& a, mu_1_status& b)
  {
    int w;
    w = Compare(a.mu_st, b.mu_st);
    if (w!=0) return w;
    w = Compare(a.mu_data, b.mu_data);
    if (w!=0) return w;
  return 0;
}
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);

	void random()
	{
	mu_st.random();
	mu_data.random();
	};


	void printTitle()
	{
	mu_st.printTitle();
	mu_data.printTitle();
	};


	void printValue()
	{
	mu_st.printValue();
	mu_data.printValue();
	};

  virtual void MultisetSort()
  {
    mu_st.MultisetSort();
    mu_data.MultisetSort();
  }
  void print_statistic()
  {
    mu_st.print_statistic();
    mu_data.print_statistic();
  }
  void clear() {
    mu_st.clear();
    mu_data.clear();
 };
  void undefine() {
    mu_st.undefine();
    mu_data.undefine();
 };
  void reset() {
    mu_st.reset();
    mu_data.reset();
 };
  void print() {
    mu_st.print();
    mu_data.print();
  };
  void print_diff(state *prevstate) {
    mu_st.print_diff(prevstate);
    mu_data.print_diff(prevstate);
  };
  void to_state(state *thestate) {
    mu_st.to_state(thestate);
    mu_data.to_state(thestate);
  };
virtual bool isundefined() { Error.Error("Checking undefinedness of a non-base type"); return TRUE;}
virtual bool ismember() { Error.Error("Checking membership for a non-base type"); return TRUE;}
  mu_1_status& operator= (const mu_1_status& from) {
    mu_st.value(from.mu_st.value());
    mu_data.value(from.mu_data.value());
    return *this;
  };
};

  void mu_1_status::set_self_ar( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    int l1 = strlen(n1), l2 = strlen(n2);
    strcpy( longname, n1 );
    longname[l1] = '[';
    strcpy( longname+l1+1, n2 );
    longname[l1+l2+1] = ']';
    longname[l1+l2+2] = 0;
    set_self( longname, os );
  };
  void mu_1_status::set_self_2( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    strcpy( longname, n1 );
    strcat( longname, n2 );
    set_self( longname, os );
  };
void mu_1_status::set_self(const char *n, int os)
{
  name = (char *)n;

  if (name) mu_st.set_self_2(name, ".st", os + 0 ); else mu_st.set_self_2(NULL, NULL, 0);
  if (name) mu_data.set_self_2(name, ".data", os + 8 ); else mu_data.set_self_2(NULL, NULL, 0);
}

mu_1_status::~mu_1_status()
{
}

/*** end record declaration ***/
mu_1_status mu_1_status_undefined_var;

class mu_1_NODE: public mu__byte
{
 public:
  inline int operator=(int val) { return value(val); };
  inline int operator=(const mu_1_NODE& val){ return value(val.value());};
  inline operator int() const { return value(); };
  static const char *values[];
  friend ostream& operator<< (ostream& s, mu_1_NODE& val)
    {
      if (val.defined())
	return ( s << mu_1_NODE::values[ int(val) - 7 ] );
      else
	return ( s << "Undefined" );
    };

  mu_1_NODE (const char *name, int os): mu__byte(7, 8, 2, name, os) {};
  mu_1_NODE (void): mu__byte(7, 8, 2) {};
  mu_1_NODE (int val): mu__byte(7, 8, 2, "Parameter or function result.", 0)
    { operator=(val); };
  const char * Name() { return values[ value() -7]; };
  virtual void print()
    {
      if (defined()) cout << name << ':' << values[ value() - 7] << '\n';
      else cout << name << ":Undefined\n";
    };
  void print_statistic() {};
friend int CompareWeight(mu_1_NODE& a, mu_1_NODE& b)
{
  if (!a.defined() && b.defined())
    return -1;
  else if (a.defined() && !b.defined())
    return 1;
  else
    return 0;
}
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);

	 static int number_r_s;
	virtual void random()
	{
		if (defined())
		{
			int random_number = random1(number_r_s);
			value(random_number + 7);
		}
	}

	virtual void printTitle()
	{
		csvFile<<name<<",";
	}
	virtual void printValue()
	{
		if (defined())
		{
			csvFile<<values[ value() -7]<<",";
		}
		else
		{
			csvFile<<"Undefined,";
		}
	}
};
const char *mu_1_NODE::values[] =
  { "NODE_1","NODE_2",NULL };


int mu_1_NODE::number_r_s = 2;
/*** end scalarset declaration ***/
mu_1_NODE mu_1_NODE_undefined_var;

class mu_1__type_0
{
 public:
  mu_1_status array[ 2 ];
 public:
  char *name;
  char longname[BUFFER_SIZE/4];
  void set_self( const char *n, int os);
  void set_self_2( const char *n, const char *n2, int os);
  void set_self_ar( const char *n, const char *n2, int os);
  mu_1__type_0 (const char *n, int os) { set_self(n, os); };
  mu_1__type_0 ( void ) {};
  virtual ~mu_1__type_0 ();
  mu_1_status& operator[] (int index) /* const */
  {
#ifndef NO_RUN_TIME_CHECKING
    if ( ( index >= 7 ) && ( index <= 8 ) )
      return array[ index - 7 ];
    else
      {
	if (index==UNDEFVAL) 
	  Error.Error("Indexing to %s using an undefined value.", name);
	else
	  Error.Error("Funny index value %d for %s: NODE is internally represented from 7 to 8.\nInternal Error in Type checking.",index, name);
	return array[0];
      }
#else
    return array[ index - 7 ];
#endif
  };
  mu_1__type_0& operator= (const mu_1__type_0& from)
  {
    for (int i = 0; i < 2; i++)
      array[i] = from.array[i];
    return *this;
  }

friend int CompareWeight(mu_1__type_0& a, mu_1__type_0& b)
  {
    return 0;
  }
friend int Compare(mu_1__type_0& a, mu_1__type_0& b)
  {
    int w;
    for (int i=0; i<2; i++) {
      w = Compare(a.array[i], b.array[i]);
      if (w!=0) return w;
    }
    return 0;
  }
  virtual void Permute(PermSet& Perm, int i);
  virtual void SimpleCanonicalize(PermSet& Perm);
  virtual void Canonicalize(PermSet& Perm);
  virtual void SimpleLimit(PermSet& Perm);
  virtual void ArrayLimit(PermSet& Perm);
  virtual void Limit(PermSet& Perm);
  virtual void MultisetLimit(PermSet& Perm);

	void random()
	{
		for (int i = 0; i < 2; i++)
		{
			array[i].random();
		}
	};


	void printTitle()
	{
		for (int i = 0; i < 2; i++)
		{
			array[i].printTitle();
		}
	};


	void printValue()
	{
		for (int i = 0; i < 2; i++)
		{
			array[i].printValue();
		}
	};

  virtual void MultisetSort()
  {
    for (int i=0; i<2; i++)
      array[i].MultisetSort();
  }
  void print_statistic()
  {
    for (int i=0; i<2; i++)
      array[i].print_statistic();
  }
  void clear() { for (int i = 0; i < 2; i++) array[i].clear(); };

  void undefine() { for (int i = 0; i < 2; i++) array[i].undefine(); };

  void reset() { for (int i = 0; i < 2; i++) array[i].reset(); };

  void to_state(state *thestate)
  {
    for (int i = 0; i < 2; i++)
      array[i].to_state(thestate);
  };

  void print()
  {
    for (int i = 0; i < 2; i++)
      array[i].print(); };

  void print_diff(state *prevstate)
  {
    for (int i = 0; i < 2; i++)
      array[i].print_diff(prevstate);
  };
};

  void mu_1__type_0::set_self_ar( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    int l1 = strlen(n1), l2 = strlen(n2);
    strcpy( longname, n1 );
    longname[l1] = '[';
    strcpy( longname+l1+1, n2 );
    longname[l1+l2+1] = ']';
    longname[l1+l2+2] = 0;
    set_self( longname, os );
  };
  void mu_1__type_0::set_self_2( const char *n1, const char *n2, int os ) {
    if (n1 == NULL) {set_self(NULL, 0); return;}
    strcpy( longname, n1 );
    strcat( longname, n2 );
    set_self( longname, os );
  };
void mu_1__type_0::set_self( const char *n, int os)
  {
    int i=0;
    name = (char *)n;

if (n) array[i].set_self_ar(n,"NODE_1", i * 16 + os); else array[i].set_self_ar(NULL, NULL, 0); i++;
if (n) array[i].set_self_ar(n,"NODE_2", i * 16 + os); else array[i].set_self_ar(NULL, NULL, 0); i++;
}
mu_1__type_0::~mu_1__type_0()
{
}
/*** end array declaration ***/
mu_1__type_0 mu_1__type_0_undefined_var;

const int mu_NODENUMS = 2;
const int mu_dataNums = 2;
const int mu_I = 1;
const int mu_T = 2;
const int mu_C = 3;
const int mu_E = 4;
const int mu_DATA_1 = 5;
const int mu_DATA_2 = 6;
const int mu_NODE_1 = 7;
const int mu_NODE_2 = 8;
/*** Variable declaration ***/
mu_1__type_0 mu_n("n",0);

/*** Variable declaration ***/
mu_0_boolean mu_x("x",32);

/*** Variable declaration ***/
mu_1_DATA mu_auxDATA("auxDATA",40);

/*** Variable declaration ***/
mu_1_DATA mu_memDATA("memDATA",48);





/********************
  The world
 ********************/
ofstream csvFile;
void world_class::random()
{
  mu_n.random();
  mu_x.random();
  mu_auxDATA.random();
  mu_memDATA.random();
}
void world_class::printTitle()
{
  mu_n.printTitle();
  mu_x.printTitle();
  mu_auxDATA.printTitle();
  mu_memDATA.printTitle();
csvFile<<"isgood"<<"\n";
}
void world_class::printValue(bool a)
{
  mu_n.printValue();
  mu_x.printValue();
  mu_auxDATA.printValue();
  mu_memDATA.printValue();
	if(a == true)
	{
		csvFile<<"true"<<"\n";
	}
	else
	{
		csvFile<<"false"<<"\n";
	}
}
void world_class::clear()
{
  mu_n.clear();
  mu_x.clear();
  mu_auxDATA.clear();
  mu_memDATA.clear();
}
void world_class::undefine()
{
  mu_n.undefine();
  mu_x.undefine();
  mu_auxDATA.undefine();
  mu_memDATA.undefine();
}
void world_class::reset()
{
  mu_n.reset();
  mu_x.reset();
  mu_auxDATA.reset();
  mu_memDATA.reset();
}
void world_class::print()
{
  static int num_calls = 0; /* to ward off recursive calls. */
  if ( num_calls == 0 ) {
    num_calls++;
  mu_n.print();
  mu_x.print();
  mu_auxDATA.print();
  mu_memDATA.print();
    num_calls--;
}
}
void world_class::print_statistic()
{
  static int num_calls = 0; /* to ward off recursive calls. */
  if ( num_calls == 0 ) {
    num_calls++;
  mu_n.print_statistic();
  mu_x.print_statistic();
  mu_auxDATA.print_statistic();
  mu_memDATA.print_statistic();
    num_calls--;
}
}
void world_class::print_diff( state *prevstate )
{
  if ( prevstate != NULL )
  {
    mu_n.print_diff(prevstate);
    mu_x.print_diff(prevstate);
    mu_auxDATA.print_diff(prevstate);
    mu_memDATA.print_diff(prevstate);
  }
  else
print();
}
void world_class::to_state(state *newstate)
{
  mu_n.to_state( newstate );
  mu_x.to_state( newstate );
  mu_auxDATA.to_state( newstate );
  mu_memDATA.to_state( newstate );
}
void world_class::setstate(state *thestate)
{
}


/********************
  Rule declarations
 ********************/
/******************** RuleBase0 ********************/
class RuleBase0
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static mu_1_DATA mu_data;
    mu_data.value((r % 2) + 5);
    r = r / 2;
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return tsprintf("Store, data:%s, i:%s", mu_data.Name(), mu_i.Name());
  }
  bool Condition(unsigned r)
  {
    static mu_1_DATA mu_data;
    mu_data.value((r % 2) + 5);
    r = r / 2;
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return (mu_n[mu_i].mu_st) == (mu_C);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 0;
    static mu_1_DATA mu_data;
    mu_data.value((r % 2) + 5);
    r = r / 2;
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    while (what_rule < 4 )
      {
	if ( ( TRUE  ) ) {
	      if ((mu_n[mu_i].mu_st) == (mu_C)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 2;
	}
	else
	  what_rule += 2;
    r = what_rule - 0;
    mu_data.value((r % 2) + 5);
    r = r / 2;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    }
  }

  void Code(unsigned r)
  {
    static mu_1_DATA mu_data;
    mu_data.value((r % 2) + 5);
    r = r / 2;
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
mu_auxDATA = mu_data;
mu_n[mu_i].mu_data = mu_data;
  };

};
/******************** RuleBase1 ********************/
class RuleBase1
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return tsprintf("Idle, i:%s", mu_i.Name());
  }
  bool Condition(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return (mu_n[mu_i].mu_st) == (mu_E);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 4;
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    while (what_rule < 6 )
      {
	if ( ( TRUE  ) ) {
	      if ((mu_n[mu_i].mu_st) == (mu_E)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 4;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    }
  }

  void Code(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
mu_n[mu_i].mu_st = mu_I;
mu_x = mu_true;
mu_memDATA = mu_n[mu_i].mu_data;
mu_n[mu_i].mu_data.undefine();
  };

};
/******************** RuleBase2 ********************/
class RuleBase2
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return tsprintf("Exit, i:%s", mu_i.Name());
  }
  bool Condition(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return (mu_n[mu_i].mu_st) == (mu_C);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 6;
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    while (what_rule < 8 )
      {
	if ( ( TRUE  ) ) {
	      if ((mu_n[mu_i].mu_st) == (mu_C)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 6;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    }
  }

  void Code(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
mu_n[mu_i].mu_st = mu_E;
  };

};
/******************** RuleBase3 ********************/
class RuleBase3
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return tsprintf("Crit, i:%s", mu_i.Name());
  }
  bool Condition(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
bool mu__boolexpr1;
  if (!((mu_n[mu_i].mu_st) == (mu_T))) mu__boolexpr1 = FALSE ;
  else {
  mu__boolexpr1 = ((mu_x) == (mu_true)) ; 
}
    return mu__boolexpr1;
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 8;
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    while (what_rule < 10 )
      {
	if ( ( TRUE  ) ) {
bool mu__boolexpr2;
  if (!((mu_n[mu_i].mu_st) == (mu_T))) mu__boolexpr2 = FALSE ;
  else {
  mu__boolexpr2 = ((mu_x) == (mu_true)) ; 
}
	      if (mu__boolexpr2) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 8;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    }
  }

  void Code(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
mu_n[mu_i].mu_st = mu_C;
mu_x = mu_false;
if (mu_memDATA.isundefined())
  mu_n[mu_i].mu_data.undefine();
else
  mu_n[mu_i].mu_data = mu_memDATA;
mu_memDATA.undefine();
  };

};
/******************** RuleBase4 ********************/
class RuleBase4
{
public:
  int Priority()
  {
    return 0;
  }
  char * Name(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return tsprintf("Try, i:%s", mu_i.Name());
  }
  bool Condition(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    return (mu_n[mu_i].mu_st) == (mu_I);
  }

  void NextRule(unsigned & what_rule)
  {
    unsigned r = what_rule - 10;
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    while (what_rule < 12 )
      {
	if ( ( TRUE  ) ) {
	      if ((mu_n[mu_i].mu_st) == (mu_I)) {
		if ( ( TRUE  ) )
		  return;
		else
		  what_rule++;
	      }
	      else
		what_rule += 1;
	}
	else
	  what_rule += 1;
    r = what_rule - 10;
    mu_i.value((r % 2) + 7);
    r = r / 2;
    }
  }

  void Code(unsigned r)
  {
    static mu_1_NODE mu_i;
    mu_i.value((r % 2) + 7);
    r = r / 2;
mu_n[mu_i].mu_st = mu_T;
  };

};
class NextStateGenerator
{
  RuleBase0 R0;
  RuleBase1 R1;
  RuleBase2 R2;
  RuleBase3 R3;
  RuleBase4 R4;
public:
void SetNextEnabledRule(unsigned & what_rule)
{
  category = CONDITION;
  if (what_rule<4)
    { R0.NextRule(what_rule);
      if (what_rule<4) return; }
  if (what_rule>=4 && what_rule<6)
    { R1.NextRule(what_rule);
      if (what_rule<6) return; }
  if (what_rule>=6 && what_rule<8)
    { R2.NextRule(what_rule);
      if (what_rule<8) return; }
  if (what_rule>=8 && what_rule<10)
    { R3.NextRule(what_rule);
      if (what_rule<10) return; }
  if (what_rule>=10 && what_rule<12)
    { R4.NextRule(what_rule);
      if (what_rule<12) return; }
}
bool Condition(unsigned r)
{
  category = CONDITION;
  if (r<=3) return R0.Condition(r-0);
  if (r>=4 && r<=5) return R1.Condition(r-4);
  if (r>=6 && r<=7) return R2.Condition(r-6);
  if (r>=8 && r<=9) return R3.Condition(r-8);
  if (r>=10 && r<=11) return R4.Condition(r-10);
Error.Notrace("Internal: NextStateGenerator -- checking condition for nonexisting rule.");
return 0;}
void Code(unsigned r)
{
  if (r<=3) { R0.Code(r-0); return; } 
  if (r>=4 && r<=5) { R1.Code(r-4); return; } 
  if (r>=6 && r<=7) { R2.Code(r-6); return; } 
  if (r>=8 && r<=9) { R3.Code(r-8); return; } 
  if (r>=10 && r<=11) { R4.Code(r-10); return; } 
}
int Priority(unsigned short r)
{
  if (r<=3) { return R0.Priority(); } 
  if (r>=4 && r<=5) { return R1.Priority(); } 
  if (r>=6 && r<=7) { return R2.Priority(); } 
  if (r>=8 && r<=9) { return R3.Priority(); } 
  if (r>=10 && r<=11) { return R4.Priority(); } 
return 0;}
char * Name(unsigned r)
{
  if (r<=3) return R0.Name(r-0);
  if (r>=4 && r<=5) return R1.Name(r-4);
  if (r>=6 && r<=7) return R2.Name(r-6);
  if (r>=8 && r<=9) return R3.Name(r-8);
  if (r>=10 && r<=11) return R4.Name(r-10);
  return NULL;
}
};
const unsigned numrules = 12;

/********************
  parameter
 ********************/
#define RULES_IN_WORLD 12


/********************
  Startstate records
 ********************/
/******************** StartStateBase0 ********************/
class StartStateBase0
{
public:
  char * Name(unsigned short r)
  {
    static mu_1_DATA mu_d;
    mu_d.value((r % 2) + 5);
    r = r / 2;
    return tsprintf("Startstate 0, d:%s", mu_d.Name());
  }
  void Code(unsigned short r)
  {
    static mu_1_DATA mu_d;
    mu_d.value((r % 2) + 5);
    r = r / 2;
{
for(int mu_i = 7; mu_i <= 8; mu_i++) {
mu_n[mu_i].mu_st = mu_I;
mu_n[mu_i].mu_data.undefine();
};
};
mu_x = mu_true;
mu_auxDATA.undefine();
mu_memDATA.undefine();
  };

};
class StartStateGenerator
{
  StartStateBase0 S0;
public:
void Code(unsigned short r)
{
  if (r<=1) { S0.Code(r-0); return; }
}
char * Name(unsigned short r)
{
  if (r<=1) return S0.Name(r-0);
  return NULL;
}
};
const rulerec startstates[] = {
{ NULL, NULL, NULL, FALSE},
};
unsigned short StartStateManager::numstartstates = 2;

/********************
  Invariant records
 ********************/
int mu__invariant_3( const mu_1_NODE &mu_i) // Invariant "dataprop"
{
bool mu__boolexpr4;
  if (!((mu_n[mu_i].mu_st) == (mu_C))) mu__boolexpr4 = TRUE ;
  else {
  mu__boolexpr4 = ((mu_n[mu_i].mu_data) == (mu_auxDATA)) ; 
}
return mu__boolexpr4;
};

bool mu__condition_6() // Condition for Rule "dataprop, i:NODE_2"
{
  return mu__invariant_3( mu_NODE_2 );
}

bool mu__condition_7() // Condition for Rule "dataprop, i:NODE_1"
{
  return mu__invariant_3( mu_NODE_1 );
}

/**** end rule declaration ****/

int mu__invariant_8( const mu_1_NODE &mu_j, const mu_1_NODE &mu_i) // Invariant "coherence"
{
bool mu__boolexpr9;
  if (!((mu_i) != (mu_j))) mu__boolexpr9 = TRUE ;
  else {
bool mu__boolexpr10;
  if (!((mu_n[mu_i].mu_st) == (mu_C))) mu__boolexpr10 = TRUE ;
  else {
  mu__boolexpr10 = ((mu_n[mu_j].mu_st) != (mu_C)) ; 
}
  mu__boolexpr9 = (mu__boolexpr10) ; 
}
return mu__boolexpr9;
};

bool mu__condition_13() // Condition for Rule "coherence, j:NODE_2, i:NODE_2"
{
  return mu__invariant_8( mu_NODE_2, mu_NODE_2 );
}

bool mu__condition_14() // Condition for Rule "coherence, j:NODE_2, i:NODE_1"
{
  return mu__invariant_8( mu_NODE_2, mu_NODE_1 );
}

bool mu__condition_16() // Condition for Rule "coherence, j:NODE_1, i:NODE_2"
{
  return mu__invariant_8( mu_NODE_1, mu_NODE_2 );
}

bool mu__condition_17() // Condition for Rule "coherence, j:NODE_1, i:NODE_1"
{
  return mu__invariant_8( mu_NODE_1, mu_NODE_1 );
}

/**** end rule declaration ****/

const rulerec invariants[] = {
{"coherence", &mu__condition_17, NULL, },
{"coherence", &mu__condition_16, NULL, },
{"coherence", &mu__condition_14, NULL, },
{"coherence", &mu__condition_13, NULL, },
{"dataprop", &mu__condition_7, NULL, },
{"dataprop", &mu__condition_6, NULL, },
};
const unsigned long numinvariants = 6;

/********************
  Normal/Canonicalization for scalarset
 ********************/
/*
x:NoScalarset
auxDATA:ScalarsetVariable
memDATA:ScalarsetVariable
n:ScalarsetArrayOfScalarset
*/

/********************
Code for symmetry
 ********************/

/********************
 Permutation Set Class
 ********************/
class PermSet
{
public:
  // book keeping
  enum PresentationType {Simple, Explicit};
  PresentationType Presentation;

  void ResetToSimple();
  void ResetToExplicit();
  void SimpleToExplicit();
  void SimpleToOne();
  bool NextPermutation();

  void Print_in_size()
  { int ret=0; for (int i=0; i<count; i++) if (in[i]) ret++; cout << "in_size:" << ret << "\n"; }


  /********************
   Simple and efficient representation
   ********************/
  int class_mu_1_NODE[2];
  int undefined_class_mu_1_NODE;// has the highest class number

  void Print_class_mu_1_NODE();
  bool OnlyOneRemain_mu_1_NODE;
  bool MTO_class_mu_1_NODE()
  {
    int i,j;
    if (OnlyOneRemain_mu_1_NODE)
      return FALSE;
    for (i=0; i<2; i++)
      for (j=0; j<2; j++)
        if (i!=j && class_mu_1_NODE[i]== class_mu_1_NODE[j])
	    return TRUE;
    OnlyOneRemain_mu_1_NODE = TRUE;
    return FALSE;
  }
  int class_mu_1_DATA[2];
  int undefined_class_mu_1_DATA;// has the highest class number

  void Print_class_mu_1_DATA();
  bool OnlyOneRemain_mu_1_DATA;
  bool MTO_class_mu_1_DATA()
  {
    int i,j;
    if (OnlyOneRemain_mu_1_DATA)
      return FALSE;
    for (i=0; i<2; i++)
      for (j=0; j<2; j++)
        if (i!=j && class_mu_1_DATA[i]== class_mu_1_DATA[j])
	    return TRUE;
    OnlyOneRemain_mu_1_DATA = TRUE;
    return FALSE;
  }
  bool AlreadyOnlyOneRemain;
  bool MoreThanOneRemain();


  /********************
   Explicit representation
  ********************/
  unsigned long size;
  unsigned long count;
  // in will be of product of factorial sizes for fast canonicalize
  // in will be of size 1 for reduced local memory canonicalize
  bool * in;

  // auxiliary for explicit representation

  // in/perm/revperm will be of factorial size for fast canonicalize
  // they will be of size 1 for reduced local memory canonicalize
  // second range will be size of the scalarset
  int * in_mu_1_NODE;
  typedef int arr_mu_1_NODE[2];
  arr_mu_1_NODE * perm_mu_1_NODE;
  arr_mu_1_NODE * revperm_mu_1_NODE;

  int size_mu_1_NODE[2];
  bool reversed_sorted_mu_1_NODE(int start, int end);
  void reverse_reversed_mu_1_NODE(int start, int end);

  int * in_mu_1_DATA;
  typedef int arr_mu_1_DATA[2];
  arr_mu_1_DATA * perm_mu_1_DATA;
  arr_mu_1_DATA * revperm_mu_1_DATA;

  int size_mu_1_DATA[2];
  bool reversed_sorted_mu_1_DATA(int start, int end);
  void reverse_reversed_mu_1_DATA(int start, int end);

  // procedure for explicit representation
  bool ok0(mu_1_NODE* perm, int size, mu_1_NODE k);
  void GenPerm0(mu_1_NODE* perm, int size, unsigned long& index);

  bool ok1(mu_1_DATA* perm, int size, mu_1_DATA k);
  void GenPerm1(mu_1_DATA* perm, int size, unsigned long& index);

  // General procedure
  PermSet();
  bool In(int i) const { return in[i]; };
  void Add(int i) { for (int j=0; j<i; j++) in[j] = FALSE;};
  void Remove(int i) { in[i] = FALSE; };
};
void PermSet::Print_class_mu_1_NODE()
{
  cout << "class_mu_1_NODE:\t";
  for (int i=0; i<2; i++)
    cout << class_mu_1_NODE[i];
  cout << " " << undefined_class_mu_1_NODE << "\n";
}
void PermSet::Print_class_mu_1_DATA()
{
  cout << "class_mu_1_DATA:\t";
  for (int i=0; i<2; i++)
    cout << class_mu_1_DATA[i];
  cout << " " << undefined_class_mu_1_DATA << "\n";
}
bool PermSet::MoreThanOneRemain()
{
  int i,j;
  if (AlreadyOnlyOneRemain)
    return FALSE;
  else {
    for (i=0; i<2; i++)
      for (j=0; j<2; j++)
        if (i!=j && class_mu_1_NODE[i]== class_mu_1_NODE[j])
	    return TRUE;
    for (i=0; i<2; i++)
      for (j=0; j<2; j++)
        if (i!=j && class_mu_1_DATA[i]== class_mu_1_DATA[j])
	    return TRUE;
  }
  AlreadyOnlyOneRemain = TRUE;
  return FALSE;
}
PermSet::PermSet()
: Presentation(Simple)
{
  int i,j,k;
  if (  args->sym_alg.mode == argsym_alg::Exhaustive_Fast_Canonicalize
     || args->sym_alg.mode == argsym_alg::Heuristic_Fast_Canonicalize) {
    mu_1_NODE Perm0[2];
    mu_1_DATA Perm1[2];

  /********************
   declaration of class variables
  ********************/
  in = new bool[4];
 in_mu_1_NODE = new int[4];
 perm_mu_1_NODE = new arr_mu_1_NODE[2];
 revperm_mu_1_NODE = new arr_mu_1_NODE[2];
 in_mu_1_DATA = new int[4];
 perm_mu_1_DATA = new arr_mu_1_DATA[2];
 revperm_mu_1_DATA = new arr_mu_1_DATA[2];

    // Set perm and revperm
    count = 0;
    for (i=7; i<=8; i++)
      {
        Perm0[0].value(i);
        GenPerm0(Perm0, 1, count);
      }
    if (count!=2)
      Error.Error( "unable to initialize PermSet");
    for (i=0; i<2; i++)
      for (j=7; j<=8; j++)
        for (k=7; k<=8; k++)
          if (revperm_mu_1_NODE[i][k-7]==j)   // k - base 
            perm_mu_1_NODE[i][j-7]=k; // j - base 
    count = 0;
    for (i=5; i<=6; i++)
      {
        Perm1[0].value(i);
        GenPerm1(Perm1, 1, count);
      }
    if (count!=2)
      Error.Error( "unable to initialize PermSet");
    for (i=0; i<2; i++)
      for (j=5; j<=6; j++)
        for (k=5; k<=6; k++)
          if (revperm_mu_1_DATA[i][k-5]==j)   // k - base 
            perm_mu_1_DATA[i][j-5]=k; // j - base 

    // setting up combination of permutations
    // for different scalarset
    int carry;
    int i_mu_1_NODE = 0;
    int i_mu_1_DATA = 0;
    size = 4;
    count = 4;
    for (i=0; i<4; i++)
      {
        carry = 1;
        in[i]= TRUE;
      in_mu_1_NODE[i] = i_mu_1_NODE;
      i_mu_1_NODE += carry;
      if (i_mu_1_NODE >= 2) { i_mu_1_NODE = 0; carry = 1; } 
      else { carry = 0; } 
      in_mu_1_DATA[i] = i_mu_1_DATA;
      i_mu_1_DATA += carry;
      if (i_mu_1_DATA >= 2) { i_mu_1_DATA = 0; carry = 1; } 
      else { carry = 0; } 
    }
  }
  else
  {

  /********************
   declaration of class variables
  ********************/
  in = new bool[1];
 in_mu_1_NODE = new int[1];
 perm_mu_1_NODE = new arr_mu_1_NODE[1];
 revperm_mu_1_NODE = new arr_mu_1_NODE[1];
 in_mu_1_DATA = new int[1];
 perm_mu_1_DATA = new arr_mu_1_DATA[1];
 revperm_mu_1_DATA = new arr_mu_1_DATA[1];
  in[0] = TRUE;
    in_mu_1_NODE[0] = 0;
    in_mu_1_DATA[0] = 0;
  }
}
void PermSet::ResetToSimple()
{
  int i;
  for (i=0; i<2; i++)
    class_mu_1_NODE[i]=0;
  undefined_class_mu_1_NODE=0;
  OnlyOneRemain_mu_1_NODE = FALSE;
  for (i=0; i<2; i++)
    class_mu_1_DATA[i]=0;
  undefined_class_mu_1_DATA=0;
  OnlyOneRemain_mu_1_DATA = FALSE;

  AlreadyOnlyOneRemain = FALSE;
  Presentation = Simple;
}
void PermSet::ResetToExplicit()
{
  for (int i=0; i<4; i++) in[i] = TRUE;
  Presentation = Explicit;
}
void PermSet::SimpleToExplicit()
{
  int i,j,k;
  int start, class_size;
  int start_mu_1_NODE[2];
  int size_mu_1_NODE[2];
  bool should_be_in_mu_1_NODE[2];
  int start_mu_1_DATA[2];
  int size_mu_1_DATA[2];
  bool should_be_in_mu_1_DATA[2];

  // Setup range for mapping
  start = 0;
  for (j=0; j<=undefined_class_mu_1_NODE; j++) // class number
    {
      class_size = 0;
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	if (class_mu_1_NODE[k]==j)
	  class_size++;
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	if (class_mu_1_NODE[k]==j)
	  {
	    size_mu_1_NODE[k] = class_size;
	    start_mu_1_NODE[k] = start;
	  }
      start+=class_size;
    }
  start = 0;
  for (j=0; j<=undefined_class_mu_1_DATA; j++) // class number
    {
      class_size = 0;
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	if (class_mu_1_DATA[k]==j)
	  class_size++;
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	if (class_mu_1_DATA[k]==j)
	  {
	    size_mu_1_DATA[k] = class_size;
	    start_mu_1_DATA[k] = start;
	  }
      start+=class_size;
    }

  // To be In or not to be
  for (i=0; i<2; i++) // set up
    should_be_in_mu_1_NODE[i] = TRUE;
  for (i=0; i<2; i++) // to be in or not to be
    for (k=0; k<2; k++) // step through class_mu_1_pid[k]
      if (! (perm_mu_1_NODE[i][k]-7 >=start_mu_1_NODE[k] 
	     && perm_mu_1_NODE[i][k]-7 < start_mu_1_NODE[k] + size_mu_1_NODE[k]) )
  	    {
	      should_be_in_mu_1_NODE[i] = FALSE;
	      break;
	    }
  for (i=0; i<2; i++) // set up
    should_be_in_mu_1_DATA[i] = TRUE;
  for (i=0; i<2; i++) // to be in or not to be
    for (k=0; k<2; k++) // step through class_mu_1_pid[k]
      if (! (perm_mu_1_DATA[i][k]-5 >=start_mu_1_DATA[k] 
	     && perm_mu_1_DATA[i][k]-5 < start_mu_1_DATA[k] + size_mu_1_DATA[k]) )
  	    {
	      should_be_in_mu_1_DATA[i] = FALSE;
	      break;
	    }

  // setup explicit representation 
  // Set perm and revperm
  for (i=0; i<4; i++)
    {
      in[i] = TRUE;
      if (in[i] && !should_be_in_mu_1_NODE[in_mu_1_NODE[i]]) in[i] = FALSE;
      if (in[i] && !should_be_in_mu_1_DATA[in_mu_1_DATA[i]]) in[i] = FALSE;
    }
  Presentation = Explicit;
  if (args->test_parameter1.value==0) Print_in_size();
}
void PermSet::SimpleToOne()
{
  int i,j,k;
  int class_size;
  int start;


  // Setup range for mapping
  start = 0;
  for (j=0; j<=undefined_class_mu_1_NODE; j++) // class number
    {
      class_size = 0;
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	if (class_mu_1_NODE[k]==j)
	  class_size++;
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	if (class_mu_1_NODE[k]==j)
	  {
	    size_mu_1_NODE[k] = class_size;
	  }
      start+=class_size;
    }
  start = 0;
  for (j=0; j<=undefined_class_mu_1_DATA; j++) // class number
    {
      class_size = 0;
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	if (class_mu_1_DATA[k]==j)
	  class_size++;
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	if (class_mu_1_DATA[k]==j)
	  {
	    size_mu_1_DATA[k] = class_size;
	  }
      start+=class_size;
    }
  start = 0;
  for (j=0; j<=undefined_class_mu_1_NODE; j++) // class number
    {
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	    if (class_mu_1_NODE[k]==j)
	      revperm_mu_1_NODE[0][start++] = k+7;
    }
  for (j=0; j<2; j++)
    for (k=0; k<2; k++)
      if (revperm_mu_1_NODE[0][k]==j+7)
        perm_mu_1_NODE[0][j]=k+7;
  start = 0;
  for (j=0; j<=undefined_class_mu_1_DATA; j++) // class number
    {
      for (k=0; k<2; k++) // step through class_mu_1_pid[k]
	    if (class_mu_1_DATA[k]==j)
	      revperm_mu_1_DATA[0][start++] = k+5;
    }
  for (j=0; j<2; j++)
    for (k=0; k<2; k++)
      if (revperm_mu_1_DATA[0][k]==j+5)
        perm_mu_1_DATA[0][j]=k+5;
  Presentation = Explicit;
}
bool PermSet::ok0(mu_1_NODE* Perm, int size, mu_1_NODE k)
{
  for (int i=0; i<size; i++)
    if(Perm[i].value()==k)
      return FALSE;
  return TRUE;
}
void PermSet::GenPerm0(mu_1_NODE* Perm,int size, unsigned long& count)
{
  int i;
  if (size!=2)
    {
      for (i=7; i<=8; i++)
        if(ok0(Perm,size,i))
          {
            Perm[size].value(i);
            GenPerm0(Perm, size+1, count);
          }
    }
  else
    {
      for (i=7; i<=8; i++)
        revperm_mu_1_NODE[count][i-7]=Perm[i-7].value();// i - base
      count++;
    }
}
bool PermSet::ok1(mu_1_DATA* Perm, int size, mu_1_DATA k)
{
  for (int i=0; i<size; i++)
    if(Perm[i].value()==k)
      return FALSE;
  return TRUE;
}
void PermSet::GenPerm1(mu_1_DATA* Perm,int size, unsigned long& count)
{
  int i;
  if (size!=2)
    {
      for (i=5; i<=6; i++)
        if(ok1(Perm,size,i))
          {
            Perm[size].value(i);
            GenPerm1(Perm, size+1, count);
          }
    }
  else
    {
      for (i=5; i<=6; i++)
        revperm_mu_1_DATA[count][i-5]=Perm[i-5].value();// i - base
      count++;
    }
}
bool PermSet::reversed_sorted_mu_1_NODE(int start, int end)
{
  int i,j;

  for (i=start; i<end; i++)
    if (revperm_mu_1_NODE[0][i]<revperm_mu_1_NODE[0][i+1])
      return FALSE;
  return TRUE;
}
void PermSet::reverse_reversed_mu_1_NODE(int start, int end)
{
  int i,j;
  int temp;

  for (i=start, j=end; i<j; i++,j--) 
    {
      temp = revperm_mu_1_NODE[0][j];
      revperm_mu_1_NODE[0][j] = revperm_mu_1_NODE[0][i];
      revperm_mu_1_NODE[0][i] = temp;
    }
}
bool PermSet::reversed_sorted_mu_1_DATA(int start, int end)
{
  int i,j;

  for (i=start; i<end; i++)
    if (revperm_mu_1_DATA[0][i]<revperm_mu_1_DATA[0][i+1])
      return FALSE;
  return TRUE;
}
void PermSet::reverse_reversed_mu_1_DATA(int start, int end)
{
  int i,j;
  int temp;

  for (i=start, j=end; i<j; i++,j--) 
    {
      temp = revperm_mu_1_DATA[0][j];
      revperm_mu_1_DATA[0][j] = revperm_mu_1_DATA[0][i];
      revperm_mu_1_DATA[0][i] = temp;
    }
}
bool PermSet::NextPermutation()
{
  bool nexted = FALSE;
  int start, end; 
  int class_size;
  int temp;
  int j,k;

  // algorithm
  // for each class
  //   if forall in the same class reverse_sorted, 
  //     { sort again; goto next class }
  //   else
  //     {
  //       nexted = TRUE;
  //       for (j from l to r)
  // 	       if (for all j+ are reversed sorted)
  // 	         {
  // 	           swap j, j+1
  // 	           sort all j+ again
  // 	           break;
  // 	         }
  //     }
  for (start = 0; start < 2; )
    {
      end = start-1+size_mu_1_NODE[revperm_mu_1_NODE[0][start]-7];
      if (reversed_sorted_mu_1_NODE(start,end))
	       {
	  reverse_reversed_mu_1_NODE(start,end);
	  start = end+1;
	}
      else
	{
	  nexted = TRUE;
	  for (j = start; j<end; j++)
	    {
	      if (reversed_sorted_mu_1_NODE(j+1,end))
		{
		  for (k = end; k>j; k--)
		    {
		      if (revperm_mu_1_NODE[0][j]<revperm_mu_1_NODE[0][k])
			{
			  // swap j, k
			  temp = revperm_mu_1_NODE[0][j];
			  revperm_mu_1_NODE[0][j] = revperm_mu_1_NODE[0][k];
			  revperm_mu_1_NODE[0][k] = temp;
			  break;
			}
		    }
		  reverse_reversed_mu_1_NODE(j+1,end);
		  break;
		}
	    }
	  break;
	}
    }
if (!nexted) {
  for (start = 0; start < 2; )
    {
      end = start-1+size_mu_1_DATA[revperm_mu_1_DATA[0][start]-5];
      if (reversed_sorted_mu_1_DATA(start,end))
	       {
	  reverse_reversed_mu_1_DATA(start,end);
	  start = end+1;
	}
      else
	{
	  nexted = TRUE;
	  for (j = start; j<end; j++)
	    {
	      if (reversed_sorted_mu_1_DATA(j+1,end))
		{
		  for (k = end; k>j; k--)
		    {
		      if (revperm_mu_1_DATA[0][j]<revperm_mu_1_DATA[0][k])
			{
			  // swap j, k
			  temp = revperm_mu_1_DATA[0][j];
			  revperm_mu_1_DATA[0][j] = revperm_mu_1_DATA[0][k];
			  revperm_mu_1_DATA[0][k] = temp;
			  break;
			}
		    }
		  reverse_reversed_mu_1_DATA(j+1,end);
		  break;
		}
	    }
	  break;
	}
    }
}
if (!nexted) return FALSE;
  for (j=0; j<2; j++)
    for (k=0; k<2; k++)
      if (revperm_mu_1_NODE[0][k]==j+7)   // k - base 
	perm_mu_1_NODE[0][j]=k+7; // j - base 
  for (j=0; j<2; j++)
    for (k=0; k<2; k++)
      if (revperm_mu_1_DATA[0][k]==j+5)   // k - base 
	perm_mu_1_DATA[0][j]=k+5; // j - base 
  return TRUE;
}

/********************
 Symmetry Class
 ********************/
class SymmetryClass
{
  PermSet Perm;
  bool BestInitialized;
  state BestPermutedState;

  // utilities
  void SetBestResult(int i, state* temp);
  void ResetBestResult() {BestInitialized = FALSE;};

public:
  // initializer
  SymmetryClass() : Perm(), BestInitialized(FALSE) {};
  ~SymmetryClass() {};

  void Normalize(state* s);

  void Exhaustive_Fast_Canonicalize(state *s);
  void Heuristic_Fast_Canonicalize(state *s);
  void Heuristic_Small_Mem_Canonicalize(state *s);
  void Heuristic_Fast_Normalize(state *s);

  void MultisetSort(state* s);
};


/********************
 Symmetry Class Members
 ********************/
void SymmetryClass::MultisetSort(state* s)
{
        mu_x.MultisetSort();
        mu_auxDATA.MultisetSort();
        mu_memDATA.MultisetSort();
        mu_n.MultisetSort();
}
void SymmetryClass::Normalize(state* s)
{
  switch (args->sym_alg.mode) {
  case argsym_alg::Exhaustive_Fast_Canonicalize:
    Exhaustive_Fast_Canonicalize(s);
    break;
  case argsym_alg::Heuristic_Fast_Canonicalize:
    Heuristic_Fast_Canonicalize(s);
    break;
  case argsym_alg::Heuristic_Small_Mem_Canonicalize:
    Heuristic_Small_Mem_Canonicalize(s);
    break;
  case argsym_alg::Heuristic_Fast_Normalize:
    Heuristic_Fast_Normalize(s);
    break;
  default:
    Heuristic_Fast_Canonicalize(s);
  }
}

/********************
 Permute and Canonicalize function for different types
 ********************/
void mu_1_state::Permute(PermSet& Perm, int i) {};
void mu_1_state::SimpleCanonicalize(PermSet& Perm) {};
void mu_1_state::Canonicalize(PermSet& Perm) {};
void mu_1_state::SimpleLimit(PermSet& Perm) {};
void mu_1_state::ArrayLimit(PermSet& Perm) {};
void mu_1_state::Limit(PermSet& Perm) {};
void mu_1_state::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for enum type.\n"); };
void mu_1_DATA::Permute(PermSet& Perm, int i)
{
  if (Perm.Presentation != PermSet::Explicit)
    Error.Error("Internal Error: Wrong Sequence of Normalization");
  if (defined())
    value(Perm.perm_mu_1_DATA[Perm.in_mu_1_DATA[i]][value()-5]); // value - base
};
void mu_1_DATA::SimpleCanonicalize(PermSet& Perm)
{
  int i, class_number;
  if (Perm.Presentation != PermSet::Simple)
    Error.Error("Internal Error: Wrong Sequence of Normalization");

  if (defined())
    if (Perm.class_mu_1_DATA[value()-5]==Perm.undefined_class_mu_1_DATA) // value - base
      {
        // it has not been mapped to any particular value
        for (i=0; i<2; i++)
          if (Perm.class_mu_1_DATA[i] == Perm.undefined_class_mu_1_DATA && i!=value()-5)
            Perm.class_mu_1_DATA[i]++;
        value(5 + Perm.undefined_class_mu_1_DATA++);
      }
    else 
      {
        value(Perm.class_mu_1_DATA[value()-5]+5);
      }
}
void mu_1_DATA::Canonicalize(PermSet& Perm)
{
  Error.Error("Calling canonicalize() for Scalarset.");
}
void mu_1_DATA::SimpleLimit(PermSet& Perm)
{
  int i, class_number;
  if (Perm.Presentation != PermSet::Simple)
    Error.Error("Internal Error: Wrong Sequence of Normalization");

  if (defined())
    if (Perm.class_mu_1_DATA[value()-5]==Perm.undefined_class_mu_1_DATA) // value - base
      {
        // it has not been mapped to any particular value
        for (i=0; i<2; i++)
          if (Perm.class_mu_1_DATA[i] == Perm.undefined_class_mu_1_DATA && i!=value()-5)
            Perm.class_mu_1_DATA[i]++;
        Perm.undefined_class_mu_1_DATA++;
      }
}
void mu_1_DATA::ArrayLimit(PermSet& Perm) {}
void mu_1_DATA::Limit(PermSet& Perm) {}
void mu_1_DATA::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset type.\n"); };
void mu_1_status::Permute(PermSet& Perm, int i)
{
  mu_data.Permute(Perm,i);
};
void mu_1_status::SimpleCanonicalize(PermSet& Perm)
{
  mu_data.SimpleCanonicalize(Perm);
};
void mu_1_status::Canonicalize(PermSet& Perm)
{
};
void mu_1_status::SimpleLimit(PermSet& Perm)
{
  mu_data.SimpleLimit(Perm);
};
void mu_1_status::ArrayLimit(PermSet& Perm){}
void mu_1_status::Limit(PermSet& Perm)
{
};
void mu_1_status::MultisetLimit(PermSet& Perm)
{
};
void mu_1_NODE::Permute(PermSet& Perm, int i)
{
  if (Perm.Presentation != PermSet::Explicit)
    Error.Error("Internal Error: Wrong Sequence of Normalization");
  if (defined())
    value(Perm.perm_mu_1_NODE[Perm.in_mu_1_NODE[i]][value()-7]); // value - base
};
void mu_1_NODE::SimpleCanonicalize(PermSet& Perm)
{
  int i, class_number;
  if (Perm.Presentation != PermSet::Simple)
    Error.Error("Internal Error: Wrong Sequence of Normalization");

  if (defined())
    if (Perm.class_mu_1_NODE[value()-7]==Perm.undefined_class_mu_1_NODE) // value - base
      {
        // it has not been mapped to any particular value
        for (i=0; i<2; i++)
          if (Perm.class_mu_1_NODE[i] == Perm.undefined_class_mu_1_NODE && i!=value()-7)
            Perm.class_mu_1_NODE[i]++;
        value(7 + Perm.undefined_class_mu_1_NODE++);
      }
    else 
      {
        value(Perm.class_mu_1_NODE[value()-7]+7);
      }
}
void mu_1_NODE::Canonicalize(PermSet& Perm)
{
  Error.Error("Calling canonicalize() for Scalarset.");
}
void mu_1_NODE::SimpleLimit(PermSet& Perm)
{
  int i, class_number;
  if (Perm.Presentation != PermSet::Simple)
    Error.Error("Internal Error: Wrong Sequence of Normalization");

  if (defined())
    if (Perm.class_mu_1_NODE[value()-7]==Perm.undefined_class_mu_1_NODE) // value - base
      {
        // it has not been mapped to any particular value
        for (i=0; i<2; i++)
          if (Perm.class_mu_1_NODE[i] == Perm.undefined_class_mu_1_NODE && i!=value()-7)
            Perm.class_mu_1_NODE[i]++;
        Perm.undefined_class_mu_1_NODE++;
      }
}
void mu_1_NODE::ArrayLimit(PermSet& Perm) {}
void mu_1_NODE::Limit(PermSet& Perm) {}
void mu_1_NODE::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset type.\n"); };
void mu_1__type_0::Permute(PermSet& Perm, int i)
{
  static mu_1__type_0 temp("Permute_mu_1__type_0",-1);
  int j;
  for (j=0; j<2; j++)
    array[j].Permute(Perm, i);
  temp = *this;
  for (j=7; j<=8; j++)
    (*this)[j] = temp[Perm.revperm_mu_1_NODE[Perm.in_mu_1_NODE[i]][j-7]];};
void mu_1__type_0::SimpleCanonicalize(PermSet& Perm)
{ Error.Error("Internal: Simple Canonicalization of Scalarset Array\n"); };
void mu_1__type_0::Canonicalize(PermSet& Perm){};
void mu_1__type_0::SimpleLimit(PermSet& Perm){}
void mu_1__type_0::ArrayLimit(PermSet& Perm)
{
  // indexes
  int i,j,k,z;
  // sorting
  int count_mu_1_NODE;
  int compare;
  static mu_1_status value[2];
  // limit
  bool exists;
  bool split;
  bool goodset_mu_1_NODE[2];
  bool pos_mu_1_NODE[2][2];
  // sorting mu_1_NODE
  // only if there is more than 1 permutation in class
  if (Perm.MTO_class_mu_1_NODE())
    {
      for (i=0; i<2; i++)
        for (j=0; j<2; j++)
          pos_mu_1_NODE[i][j]=FALSE;
      count_mu_1_NODE = 0;
      for (i=0; i<2; i++)
        {
          for (j=0; j<count_mu_1_NODE; j++)
            {
              compare = CompareWeight(value[j],(*this)[i+7]);
              if (compare==0)
                {
                  pos_mu_1_NODE[j][i]= TRUE;
                  break;
                }
              else if (compare>0)
                {
                  for (k=count_mu_1_NODE; k>j; k--)
                    {
                      value[k] = value[k-1];
                      for (z=0; z<2; z++)
                        pos_mu_1_NODE[k][z] = pos_mu_1_NODE[k-1][z];
                    }
                  value[j] = (*this)[i+7];
                  for (z=0; z<2; z++)
                    pos_mu_1_NODE[j][z] = FALSE;
                  pos_mu_1_NODE[j][i] = TRUE;
                  count_mu_1_NODE++;
                  break;
                }
            }
          if (j==count_mu_1_NODE)
            {
              value[j] = (*this)[i+7];
              for (z=0; z<2; z++)
                pos_mu_1_NODE[j][z] = FALSE;
              pos_mu_1_NODE[j][i] = TRUE;
              count_mu_1_NODE++;
            }
        }
    }
  // if there is more than 1 permutation in class
  if (Perm.MTO_class_mu_1_NODE() && count_mu_1_NODE>1)
    {
      // limit
      for (j=0; j<2; j++) // class priority
        {
          for (i=0; i<count_mu_1_NODE; i++) // for value priority
            {
              exists = FALSE;
              for (k=0; k<2; k++) // step through class
                goodset_mu_1_NODE[k] = FALSE;
              for (k=0; k<2; k++) // step through class
                if (pos_mu_1_NODE[i][k] && Perm.class_mu_1_NODE[k] == j)
                  {
                    exists = TRUE;
                    goodset_mu_1_NODE[k] = TRUE;
                    pos_mu_1_NODE[i][k] = FALSE;
                  }
              if (exists)
                {
                  split=FALSE;
                  for (k=0; k<2; k++)
                    if ( Perm.class_mu_1_NODE[k] == j && !goodset_mu_1_NODE[k] ) 
                      split= TRUE;
                  if (split)
                    {
                      for (k=0; k<2; k++)
                        if (Perm.class_mu_1_NODE[k]>j
                            || ( Perm.class_mu_1_NODE[k] == j && !goodset_mu_1_NODE[k] ) )
                          Perm.class_mu_1_NODE[k]++;
                      Perm.undefined_class_mu_1_NODE++;
                    }
                }
            }
        }
    }
}
void mu_1__type_0::Limit(PermSet& Perm)
{
  // indexes
  int i,j,k,z;
  // while guard
  bool while_guard, while_guard_temp;
  // sorting
  static mu_1_status value[2];
  // limit
  bool exists;
  bool split;
  int i0;
  int count_mu_1_NODE, oldcount_mu_1_NODE;
  bool pos_mu_1_NODE[2][2];
  bool goodset_mu_1_NODE[2];
  int count_mu_1_DATA, oldcount_mu_1_DATA;
  bool pos_mu_1_DATA[2][2];
  bool goodset_mu_1_DATA[2];
  // count_ corresponds to the number of equivalence class within the
  // scalarset value.  If count_ == size of the scalarset, then a unique
  // permutation has been found.

  // pos_ is a relation on a equivalence class number and a scalarset value.

  // initializing pos array
  for (i=0; i<2; i++)
    for (j=0; j<2; j++)
      pos_mu_1_NODE[i][j]=FALSE;
  count_mu_1_NODE = 0;
  while (1)
    {
      exists = FALSE;
      for (i=0; i<2; i++)
       if (Perm.class_mu_1_NODE[i] == count_mu_1_NODE)
         {
           pos_mu_1_NODE[count_mu_1_NODE][i]=TRUE;
           exists = TRUE;
         }
      if (exists) count_mu_1_NODE++;
      else break;
    }
  // count_ corresponds to the number of equivalence class within the
  // scalarset value.  If count_ == size of the scalarset, then a unique
  // permutation has been found.

  // pos_ is a relation on a equivalence class number and a scalarset value.

  // initializing pos array
  for (i=0; i<2; i++)
    for (j=0; j<2; j++)
      pos_mu_1_DATA[i][j]=FALSE;
  count_mu_1_DATA = 0;
  while (1)
    {
      exists = FALSE;
      for (i=0; i<2; i++)
       if (Perm.class_mu_1_DATA[i] == count_mu_1_DATA)
         {
           pos_mu_1_DATA[count_mu_1_DATA][i]=TRUE;
           exists = TRUE;
         }
      if (exists) count_mu_1_DATA++;
      else break;
    }

  // refinement -- checking priority in general
  while_guard = FALSE;
  while_guard = while_guard || (Perm.MTO_class_mu_1_NODE() && count_mu_1_NODE<2);
  while_guard = while_guard || (Perm.MTO_class_mu_1_DATA() && count_mu_1_DATA<2);
  while ( while_guard )
    {
      oldcount_mu_1_NODE = count_mu_1_NODE;
      oldcount_mu_1_DATA = count_mu_1_DATA;

      // refinement -- graph structure for two scalarsets
      //               as in array S1 of S2
      // only if there is more than 1 permutation in class
      if ( (Perm.MTO_class_mu_1_NODE() && count_mu_1_NODE<2)
           || ( Perm.MTO_class_mu_1_DATA() && count_mu_1_DATA<2) )
        {
          exists = FALSE;
          split = FALSE;
          for (k=0; k<2; k++) // step through class
            if ((*this)[k+7].mu_data.isundefined())
              exists = TRUE;
            else
              split = TRUE;
          if (exists && split)
            {
              for (i=0; i<count_mu_1_NODE; i++) // scan through array index priority
                for (j=0; j<count_mu_1_DATA; j++) //scan through element priority
                  {
                    exists = FALSE;
                    for (k=0; k<2; k++) // initialize goodset
                      goodset_mu_1_NODE[k] = FALSE;
                    for (k=0; k<2; k++) // initialize goodset
                      goodset_mu_1_DATA[k] = FALSE;
                    for (k=0; k<2; k++) // scan array index
                      // set goodsets
                      if (pos_mu_1_NODE[i][k] 
                          && !(*this)[k+7].mu_data.isundefined()
                          && pos_mu_1_DATA[j][(*this)[k+7].mu_data-5])
                        {
                          exists = TRUE;
                          goodset_mu_1_NODE[k] = TRUE;
                          goodset_mu_1_DATA[(*this)[k+7].mu_data-5] = TRUE;
                        }
                    if (exists)
                      {
                        // set split for the array index type
                        split=FALSE;
                        for (k=0; k<2; k++)
                          if ( pos_mu_1_NODE[i][k] && !goodset_mu_1_NODE[k] )
                            split= TRUE;
                        if (split)
                          {
                            // move following pos entries down 1 step
                            for (z=count_mu_1_NODE; z>i; z--)
                              for (k=0; k<2; k++)
                                pos_mu_1_NODE[z][k] = pos_mu_1_NODE[z-1][k];
                            // split pos
                            for (k=0; k<2; k++)
                              {
                                if (pos_mu_1_NODE[i][k] && !goodset_mu_1_NODE[k])
                                  pos_mu_1_NODE[i][k] = FALSE;
                                if (pos_mu_1_NODE[i+1][k] && goodset_mu_1_NODE[k])
                                  pos_mu_1_NODE[i+1][k] = FALSE;
                              }
                            count_mu_1_NODE++;
                          }
                        // set split for the element type
                        split=FALSE;
                        for (k=0; k<2; k++)
                          if ( pos_mu_1_DATA[j][k] && !goodset_mu_1_DATA[k] )
                            split= TRUE;
                        if (split)
                          {
                            // move following pos entries down 1 step
                            for (z=count_mu_1_DATA; z>j; z--)
                              for (k=0; k<2; k++)
                                pos_mu_1_DATA[z][k] = pos_mu_1_DATA[z-1][k];
                            // split pos
                            for (k=0; k<2; k++)
                              {
                                if (pos_mu_1_DATA[j][k] && !goodset_mu_1_DATA[k])
                                  pos_mu_1_DATA[j][k] = FALSE;
                                if (pos_mu_1_DATA[j+1][k] && goodset_mu_1_DATA[k])
                                  pos_mu_1_DATA[j+1][k] = FALSE;
                              }
                            count_mu_1_DATA++;
                          }
                      }
                  }
            }
        }
      while_guard = FALSE;
      while_guard = while_guard || (oldcount_mu_1_NODE!=count_mu_1_NODE);
      while_guard = while_guard || (oldcount_mu_1_DATA!=count_mu_1_DATA);
      while_guard_temp = while_guard;
      while_guard = FALSE;
      while_guard = while_guard || count_mu_1_NODE<2;
      while_guard = while_guard || count_mu_1_DATA<2;
      while_guard = while_guard && while_guard_temp;
    } // end while
  // enter the result into class
  if (Perm.MTO_class_mu_1_NODE())
    {
      for (i=0; i<2; i++)
        for (j=0; j<2; j++)
          if (pos_mu_1_NODE[i][j])
            Perm.class_mu_1_NODE[j] = i;
      Perm.undefined_class_mu_1_NODE=0;
      for (j=0; j<2; j++)
        if (Perm.class_mu_1_NODE[j]>Perm.undefined_class_mu_1_NODE)
          Perm.undefined_class_mu_1_NODE=Perm.class_mu_1_NODE[j];
    }
  // enter the result into class
  if (Perm.MTO_class_mu_1_DATA())
    {
      for (i=0; i<2; i++)
        for (j=0; j<2; j++)
          if (pos_mu_1_DATA[i][j])
            Perm.class_mu_1_DATA[j] = i;
      Perm.undefined_class_mu_1_DATA=0;
      for (j=0; j<2; j++)
        if (Perm.class_mu_1_DATA[j]>Perm.undefined_class_mu_1_DATA)
          Perm.undefined_class_mu_1_DATA=Perm.class_mu_1_DATA[j];
    }
}
void mu_1__type_0::MultisetLimit(PermSet& Perm)
{ Error.Error("Internal: calling MultisetLimit for scalarset array.\n"); };

/********************
 Auxiliary function for error trace printing
 ********************/
bool match(state* ns, StatePtr p)
{
  int i;
  static PermSet Perm;
  static state temp;
  StateCopy(&temp, ns);
  if (args->symmetry_reduction.value)
    {
      if (  args->sym_alg.mode == argsym_alg::Exhaustive_Fast_Canonicalize
         || args->sym_alg.mode == argsym_alg::Heuristic_Fast_Canonicalize) {
        Perm.ResetToExplicit();
        for (i=0; i<Perm.count; i++)
          if (Perm.In(i))
            {
              if (ns != workingstate)
                  StateCopy(workingstate, ns);
              
              mu_x.Permute(Perm,i);
              if (args->multiset_reduction.value)
                mu_x.MultisetSort();
              mu_auxDATA.Permute(Perm,i);
              if (args->multiset_reduction.value)
                mu_auxDATA.MultisetSort();
              mu_memDATA.Permute(Perm,i);
              if (args->multiset_reduction.value)
                mu_memDATA.MultisetSort();
              mu_n.Permute(Perm,i);
              if (args->multiset_reduction.value)
                mu_n.MultisetSort();
            if (p.compare(workingstate)) {
              StateCopy(workingstate,&temp); return TRUE; }
          }
        StateCopy(workingstate,&temp);
        return FALSE;
      }
      else {
        Perm.ResetToSimple();
        Perm.SimpleToOne();
        if (ns != workingstate)
          StateCopy(workingstate, ns);

          mu_x.Permute(Perm,0);
          if (args->multiset_reduction.value)
            mu_x.MultisetSort();
          mu_auxDATA.Permute(Perm,0);
          if (args->multiset_reduction.value)
            mu_auxDATA.MultisetSort();
          mu_memDATA.Permute(Perm,0);
          if (args->multiset_reduction.value)
            mu_memDATA.MultisetSort();
          mu_n.Permute(Perm,0);
          if (args->multiset_reduction.value)
            mu_n.MultisetSort();
        if (p.compare(workingstate)) {
          StateCopy(workingstate,&temp); return TRUE; }

        while (Perm.NextPermutation())
          {
            if (ns != workingstate)
              StateCopy(workingstate, ns);
              
              mu_x.Permute(Perm,0);
              if (args->multiset_reduction.value)
                mu_x.MultisetSort();
              mu_auxDATA.Permute(Perm,0);
              if (args->multiset_reduction.value)
                mu_auxDATA.MultisetSort();
              mu_memDATA.Permute(Perm,0);
              if (args->multiset_reduction.value)
                mu_memDATA.MultisetSort();
              mu_n.Permute(Perm,0);
              if (args->multiset_reduction.value)
                mu_n.MultisetSort();
            if (p.compare(workingstate)) {
              StateCopy(workingstate,&temp); return TRUE; }
          }
        StateCopy(workingstate,&temp);
        return FALSE;
      }
    }
  if (!args->symmetry_reduction.value
      && args->multiset_reduction.value)
    {
      if (ns != workingstate)
          StateCopy(workingstate, ns);
      mu_x.MultisetSort();
      mu_auxDATA.MultisetSort();
      mu_memDATA.MultisetSort();
      mu_n.MultisetSort();
      if (p.compare(workingstate)) {
        StateCopy(workingstate,&temp); return TRUE; }
      StateCopy(workingstate,&temp);
      return FALSE;
    }
  return (p.compare(ns));
}

/********************
 Canonicalization by fast exhaustive generation of
 all permutations
 ********************/
void SymmetryClass::Exhaustive_Fast_Canonicalize(state* s)
{
  int i;
  static state temp;
  Perm.ResetToExplicit();

  StateCopy(&temp, workingstate);
  ResetBestResult();
  for (i=0; i<Perm.count; i++)
    if (Perm.In(i))
      {
        StateCopy(workingstate, &temp);
        mu_x.Permute(Perm,i);
        if (args->multiset_reduction.value)
          mu_x.MultisetSort();
        SetBestResult(i, workingstate);
      }
  StateCopy(workingstate, &BestPermutedState);

  StateCopy(&temp, workingstate);
  ResetBestResult();
  for (i=0; i<Perm.count; i++)
    if (Perm.In(i))
      {
        StateCopy(workingstate, &temp);
        mu_auxDATA.Permute(Perm,i);
        if (args->multiset_reduction.value)
          mu_auxDATA.MultisetSort();
        SetBestResult(i, workingstate);
      }
  StateCopy(workingstate, &BestPermutedState);

  StateCopy(&temp, workingstate);
  ResetBestResult();
  for (i=0; i<Perm.count; i++)
    if (Perm.In(i))
      {
        StateCopy(workingstate, &temp);
        mu_memDATA.Permute(Perm,i);
        if (args->multiset_reduction.value)
          mu_memDATA.MultisetSort();
        SetBestResult(i, workingstate);
      }
  StateCopy(workingstate, &BestPermutedState);

  StateCopy(&temp, workingstate);
  ResetBestResult();
  for (i=0; i<Perm.count; i++)
    if (Perm.In(i))
      {
        StateCopy(workingstate, &temp);
        mu_n.Permute(Perm,i);
        if (args->multiset_reduction.value)
          mu_n.MultisetSort();
        SetBestResult(i, workingstate);
      }
  StateCopy(workingstate, &BestPermutedState);

};

/********************
 Canonicalization by fast simple variable canonicalization,
 fast simple scalarset array canonicalization,
 fast restriction on permutation set with simple scalarset array of scalarset,
 and fast exhaustive generation of
 all permutations for other variables
 ********************/
void SymmetryClass::Heuristic_Fast_Canonicalize(state* s)
{
  int i;
  static state temp;

  Perm.ResetToSimple();

  mu_auxDATA.SimpleCanonicalize(Perm);

  mu_memDATA.SimpleCanonicalize(Perm);

  if (Perm.MoreThanOneRemain()) {
    mu_n.ArrayLimit(Perm);
  }

  if (Perm.MoreThanOneRemain()) {
    mu_n.Limit(Perm);
  }

  Perm.SimpleToExplicit();

  StateCopy(&temp, workingstate);
  ResetBestResult();
  for (i=0; i<Perm.count; i++)
    if (Perm.In(i))
      {
        StateCopy(workingstate, &temp);
        mu_n.Permute(Perm,i);
        if (args->multiset_reduction.value)
          mu_n.MultisetSort();
        SetBestResult(i, workingstate);
      }
  StateCopy(workingstate, &BestPermutedState);

};

/********************
 Canonicalization by fast simple variable canonicalization,
 fast simple scalarset array canonicalization,
 fast restriction on permutation set with simple scalarset array of scalarset,
 and fast exhaustive generation of
 all permutations for other variables
 and use less local memory
 ********************/
void SymmetryClass::Heuristic_Small_Mem_Canonicalize(state* s)
{
  unsigned long cycle;
  static state temp;

  Perm.ResetToSimple();

  mu_auxDATA.SimpleCanonicalize(Perm);

  mu_memDATA.SimpleCanonicalize(Perm);

  if (Perm.MoreThanOneRemain()) {
    mu_n.ArrayLimit(Perm);
  }

  if (Perm.MoreThanOneRemain()) {
    mu_n.Limit(Perm);
  }

  Perm.SimpleToOne();

  StateCopy(&temp, workingstate);
  ResetBestResult();
  mu_n.Permute(Perm,0);
  if (args->multiset_reduction.value)
    mu_n.MultisetSort();
  BestPermutedState = *workingstate;
  BestInitialized = TRUE;

  cycle=1;
  while (Perm.NextPermutation())
    {
      if (args->perm_limit.value != 0
          && cycle++ >= args->perm_limit.value) break;
      StateCopy(workingstate, &temp);
      mu_n.Permute(Perm,0);
      if (args->multiset_reduction.value)
        mu_n.MultisetSort();
      switch (StateCmp(workingstate, &BestPermutedState)) {
      case -1:
        BestPermutedState = *workingstate;
        break;
      case 1:
        break;
      case 0:
        break;
      default:
        Error.Error("funny return value from StateCmp");
      }
    }
  StateCopy(workingstate, &BestPermutedState);

};

/********************
 Normalization by fast simple variable canonicalization,
 fast simple scalarset array canonicalization,
 fast restriction on permutation set with simple scalarset array of scalarset,
 and for all other variables, pick any remaining permutation
 ********************/
void SymmetryClass::Heuristic_Fast_Normalize(state* s)
{
  int i;
  static state temp;

  Perm.ResetToSimple();

  mu_auxDATA.SimpleCanonicalize(Perm);

  mu_memDATA.SimpleCanonicalize(Perm);

  if (Perm.MoreThanOneRemain()) {
    mu_n.ArrayLimit(Perm);
  }

  if (Perm.MoreThanOneRemain()) {
    mu_n.Limit(Perm);
  }

  Perm.SimpleToOne();

  mu_n.Permute(Perm,0);
  if (args->multiset_reduction.value)
    mu_n.MultisetSort();

};

/********************
  Include
 ********************/
#include "mu_epilog.hpp"
