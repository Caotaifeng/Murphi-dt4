
const

  NODE_NUM : 2;
  DATA_NUM : 2;

type

  NODE : scalarset(NODE_NUM);
  DATA : scalarset(DATA_NUM);

  CACHE_STATE : enum {CACHE_I, CACHE_S, CACHE_E};

  NODE_CMD : enum {NODE_None, NODE_Get, NODE_GetX};

  NODE_STATE : record
    ProcCmd : NODE_CMD;
    InvMarked : boolean;
    CacheState : CACHE_STATE;
    CacheData : DATA;
  end;

  DIR_STATE : record
    Pending : boolean;
    Local : boolean;
    Dirty : boolean;
    HeadVld : boolean;
    HeadPtr : NODE;
    HomeHeadPtr : boolean;
    ShrVld : boolean;
    ShrSet : array [NODE] of boolean;
    HomeShrSet : boolean;
    InvSet : array [NODE] of boolean;
    HomeInvSet : boolean;
  end;

  UNI_CMD : enum {UNI_None, UNI_Get, UNI_GetX, UNI_Put, UNI_PutX, UNI_Nak};

  UNI_MSG : record
    Cmd : UNI_CMD;
    Proc : NODE;
    HomeProc : boolean;
    Data : DATA;
  end;

  INV_CMD : enum {INV_None, INV_Inv, INV_InvAck};

  INV_MSG : record
    Cmd : INV_CMD;
  end;

  RP_CMD : enum {RP_None, RP_Replace};

  RP_MSG : record
    Cmd : RP_CMD;
  end;

  WB_CMD : enum {WB_None, WB_Wb};

  WB_MSG : record
    Cmd : WB_CMD;
    Proc : NODE;
    HomeProc : boolean;
    Data : DATA;
  end;

  SHWB_CMD : enum {SHWB_None, SHWB_ShWb, SHWB_FAck};

  SHWB_MSG : record
    Cmd : SHWB_CMD;
    Proc : NODE;
    HomeProc : boolean;
    Data : DATA;
  end;

  NAKC_CMD : enum {NAKC_None, NAKC_Nakc};

  NAKC_MSG : record
    Cmd : NAKC_CMD;
  end;

  STATE : record
  -- Program variables:
    Proc : array [NODE] of NODE_STATE;
    HomeProc : NODE_STATE;
    Dir : DIR_STATE;
    MemData : DATA;
    UniMsg : array [NODE] of UNI_MSG;
    HomeUniMsg : UNI_MSG;
    InvMsg : array [NODE] of INV_MSG;
    HomeInvMsg : INV_MSG;
    RpMsg : array [NODE] of RP_MSG;
    HomeRpMsg : RP_MSG;
    WbMsg : WB_MSG;
    ShWbMsg : SHWB_MSG;
    NakcMsg : NAKC_MSG;
  -- Auxiliary variables:
    CurrData : DATA;
  end;

var

  Sta : STATE;


ruleset h : NODE; d : DATA do
startstate "Init"
  undefine Sta;
  Sta.MemData := d;
  Sta.Dir.Pending := false;
  Sta.Dir.Local := false;
  Sta.Dir.Dirty := false;
  Sta.Dir.HeadVld := false;
  Sta.Dir.HeadPtr := h;
  Sta.Dir.HomeHeadPtr := true;
  Sta.Dir.ShrVld := false;
  Sta.WbMsg.Cmd := WB_None;
  Sta.WbMsg.Proc := h;
  Sta.WbMsg.HomeProc := true;
  Sta.WbMsg.Data := d;
  Sta.ShWbMsg.Cmd := SHWB_None;
  Sta.ShWbMsg.Proc := h;
  Sta.ShWbMsg.HomeProc := true;
  Sta.ShWbMsg.Data := d;
  Sta.NakcMsg.Cmd := NAKC_None;
  for p : NODE do
    Sta.Proc[p].ProcCmd := NODE_None;
    Sta.Proc[p].InvMarked := false;
    Sta.Proc[p].CacheState := CACHE_I;
    Sta.Proc[p].CacheData := d;
    Sta.Dir.ShrSet[p] := false;
    Sta.Dir.InvSet[p] := false;
    Sta.UniMsg[p].Cmd := UNI_None;
    Sta.UniMsg[p].Proc := h;
    Sta.UniMsg[p].HomeProc := true;
    Sta.UniMsg[p].Data := d;
    Sta.InvMsg[p].Cmd := INV_None;
    Sta.RpMsg[p].Cmd := RP_None;
  end;
  Sta.HomeProc.ProcCmd := NODE_None;
  Sta.HomeProc.InvMarked := false;
  Sta.HomeProc.CacheState := CACHE_I;
  Sta.HomeProc.CacheData := d;
  Sta.Dir.HomeShrSet := false;
  Sta.Dir.HomeInvSet := false;
  Sta.HomeUniMsg.Cmd := UNI_None;
  Sta.HomeUniMsg.Proc := h;
  Sta.HomeUniMsg.HomeProc := true;
  Sta.HomeUniMsg.Data := d;
  Sta.HomeInvMsg.Cmd := INV_None;
  Sta.HomeRpMsg.Cmd := RP_None;
  Sta.CurrData := d;
endstartstate;
endruleset;


ruleset src : NODE; data : DATA do
rule "Store"
  Sta.Proc[src].CacheState = CACHE_E
==>
begin
--
  Sta.Proc[src].CacheData := data;
  Sta.CurrData := data;
--
endrule;
endruleset;

ruleset data : DATA do
rule "Store_Home"
  Sta.HomeProc.CacheState = CACHE_E
==>
begin
--
  Sta.HomeProc.CacheData := data;
  Sta.CurrData := data;
--
endrule;
endruleset;

ruleset src : NODE do
rule "PI_Remote_Get"
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_I
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Proc[src].ProcCmd := NODE_Get;
  NxtSta.UniMsg[src].Cmd := UNI_Get;
  NxtSta.UniMsg[src].HomeProc := true;
  --undefine NxtSta.UniMsg[src].Proc;
  undefine NxtSta.UniMsg[src].Data;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "PI_Local_Get_Get"
  Sta.HomeProc.ProcCmd = NODE_None &
  Sta.HomeProc.CacheState = CACHE_I &
  !Sta.Dir.Pending & Sta.Dir.Dirty
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.HomeProc.ProcCmd := NODE_Get;
  NxtSta.Dir.Pending := true;
  NxtSta.HomeUniMsg.Cmd := UNI_Get;
  NxtSta.HomeUniMsg.Proc := Sta.Dir.HeadPtr;
  NxtSta.HomeUniMsg.HomeProc := Sta.Dir.HomeHeadPtr;
  undefine NxtSta.HomeUniMsg.Data;
--
  Sta := NxtSta;
endrule;

rule "PI_Local_Get_Put"
  Sta.HomeProc.ProcCmd = NODE_None &
  Sta.HomeProc.CacheState = CACHE_I &
  !Sta.Dir.Pending & !Sta.Dir.Dirty
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := true;
  NxtSta.HomeProc.ProcCmd := NODE_None;
  if (Sta.HomeProc.InvMarked) then
    NxtSta.HomeProc.InvMarked := false;
    NxtSta.HomeProc.CacheState := CACHE_I;
	undefine NxtSta.HomeProc.CacheData;
  else
    NxtSta.HomeProc.CacheState := CACHE_S;
    NxtSta.HomeProc.CacheData := Sta.MemData;
  end;
--
  Sta := NxtSta;
endrule;

ruleset src : NODE do
rule "PI_Remote_GetX"
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_I
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Proc[src].ProcCmd := NODE_GetX;
  NxtSta.UniMsg[src].Cmd := UNI_GetX;
  NxtSta.UniMsg[src].HomeProc := true;
  undefine NxtSta.UniMsg[src].Data;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "PI_Local_GetX_GetX"
  Sta.HomeProc.ProcCmd = NODE_None &
  ( Sta.HomeProc.CacheState = CACHE_I |
    Sta.HomeProc.CacheState = CACHE_S ) &
  !Sta.Dir.Pending & Sta.Dir.Dirty
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.HomeProc.ProcCmd := NODE_GetX;
  NxtSta.Dir.Pending := true;
  NxtSta.HomeUniMsg.Cmd := UNI_GetX;
  NxtSta.HomeUniMsg.Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.HomeUniMsg.Data;
  NxtSta.HomeUniMsg.HomeProc := Sta.Dir.HomeHeadPtr;
--
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_PutX_HeadVld"
  Sta.HomeProc.ProcCmd = NODE_None &
  ( Sta.HomeProc.CacheState = CACHE_I |
    Sta.HomeProc.CacheState = CACHE_S ) &
  !Sta.Dir.Pending & !Sta.Dir.Dirty & Sta.Dir.HeadVld
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := true;
  NxtSta.Dir.Dirty := true;

  NxtSta.Dir.Pending := true;
  NxtSta.Dir.HeadVld := false;
  undefine NxtSta.Dir.HeadPtr;
  NxtSta.Dir.ShrVld := false;

  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;

  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.HomeProc.ProcCmd := NODE_None;
  NxtSta.HomeProc.InvMarked := false;
  NxtSta.HomeProc.CacheState := CACHE_E;
  NxtSta.HomeProc.CacheData := Sta.MemData;
--
  Sta := NxtSta;
endrule;

rule "PI_Local_GetX_PutX"
  Sta.HomeProc.ProcCmd = NODE_None &
  ( Sta.HomeProc.CacheState = CACHE_I |
    Sta.HomeProc.CacheState = CACHE_S ) &
  !Sta.Dir.Pending & !Sta.Dir.Dirty & !Sta.Dir.HeadVld
==>
begin
--
  Sta.Dir.Local := true;
  Sta.Dir.Dirty := true;

  Sta.HomeProc.ProcCmd := NODE_None;
  Sta.HomeProc.InvMarked := false;
  Sta.HomeProc.CacheState := CACHE_E;
  Sta.HomeProc.CacheData := Sta.MemData;
--
endrule;

ruleset dst : NODE do
rule "PI_Remote_PutX"
  Sta.Proc[dst].ProcCmd = NODE_None &
  Sta.Proc[dst].CacheState = CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  NxtSta.WbMsg.Cmd := WB_Wb;
  NxtSta.WbMsg.Proc := dst;
  NxtSta.WbMsg.HomeProc := false;
  NxtSta.WbMsg.Data := Sta.Proc[dst].CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "PI_Local_PutX"
  Sta.HomeProc.ProcCmd = NODE_None &
  Sta.HomeProc.CacheState = CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  if (Sta.Dir.Pending) then
    NxtSta.HomeProc.CacheState := CACHE_I;
	--undefine NxtSta.HomeProc.CacheData;
    NxtSta.Dir.Dirty := false;
    NxtSta.MemData := Sta.HomeProc.CacheData;
  else
    NxtSta.HomeProc.CacheState := CACHE_I;
	undefine NxtSta.HomeProc.CacheData;
    NxtSta.Dir.Local := false;
    NxtSta.Dir.Dirty := false;
    NxtSta.MemData := Sta.HomeProc.CacheData;
  end;
--
  Sta := NxtSta;
endrule;

ruleset src : NODE do
rule "PI_Remote_Replace"
  Sta.Proc[src].ProcCmd = NODE_None &
  Sta.Proc[src].CacheState = CACHE_S
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Proc[src].CacheState := CACHE_I;
  undefine NxtSta.Proc[src].CacheData;
  NxtSta.RpMsg[src].Cmd := RP_Replace;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "PI_Local_Replace"
  Sta.HomeProc.ProcCmd = NODE_None &
  Sta.HomeProc.CacheState = CACHE_S
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := false;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;

ruleset dst : NODE do
rule "NI_Nak"
  Sta.UniMsg[dst].Cmd = UNI_Nak
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.UniMsg[dst].Cmd := UNI_None;
  undefine NxtSta.UniMsg[dst].Proc;
  undefine NxtSta.UniMsg[dst].Data;
  NxtSta.Proc[dst].ProcCmd := NODE_None;
  NxtSta.Proc[dst].InvMarked := false;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_Nak_Home"
  Sta.HomeUniMsg.Cmd = UNI_Nak
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.HomeUniMsg.Cmd := UNI_None;
  undefine NxtSta.HomeUniMsg.Proc;
  undefine NxtSta.HomeUniMsg.Data;
  NxtSta.HomeProc.ProcCmd := NODE_None;
  NxtSta.HomeProc.InvMarked := false;
--
  Sta := NxtSta;
endrule;

rule "NI_Nak_Clear"
  Sta.NakcMsg.Cmd = NAKC_Nakc
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.NakcMsg.Cmd := NAKC_None;
  NxtSta.Dir.Pending := false;
--
  Sta := NxtSta;
endrule;

ruleset src : NODE do
rule "NI_Local_Get_Nak"
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].HomeProc &
  Sta.RpMsg[src].Cmd != RP_Replace &
  ( Sta.Dir.Pending |
    Sta.Dir.Dirty & Sta.Dir.Local & Sta.HomeProc.CacheState != CACHE_E |
    Sta.Dir.Dirty & !Sta.Dir.Local & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr)
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  --undefine NxtSta.UniMsg[src].Proc;
  undefine NxtSta.UniMsg[src].Data;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_Get_Get"
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].HomeProc &
  Sta.RpMsg[src].Cmd != RP_Replace &
  !Sta.Dir.Pending & Sta.Dir.Dirty & !Sta.Dir.Local &
  (Sta.Dir.HeadPtr != src | Sta.Dir.HomeHeadPtr)
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[src].Cmd := UNI_Get;
  NxtSta.UniMsg[src].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.UniMsg[src].HomeProc := Sta.Dir.HomeHeadPtr;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_Get_Put_Head"
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].HomeProc &
  Sta.RpMsg[src].Cmd != RP_Replace &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.ShrVld := true;
  NxtSta.Dir.ShrSet[src] := true;
  for p : NODE do
    if (p = src)  then
      NxtSta.Dir.InvSet[p] := true;
    else
      NxtSta.Dir.InvSet[p] := Sta.Dir.ShrSet[p];
    end;
  end;
  NxtSta.Dir.HomeInvSet := Sta.Dir.HomeShrSet;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Data := Sta.MemData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_Get_Put"
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].HomeProc &
  Sta.RpMsg[src].Cmd != RP_Replace &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & !Sta.Dir.HeadVld
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
    NxtSta.Dir.HeadVld := true;
    NxtSta.Dir.HeadPtr := src;
    NxtSta.Dir.HomeHeadPtr := false;
    NxtSta.UniMsg[src].Cmd := UNI_Put;
    NxtSta.UniMsg[src].Data := Sta.MemData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_Get_Put_Dirty"
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].HomeProc &
  Sta.RpMsg[src].Cmd != RP_Replace &
  !Sta.Dir.Pending &
  Sta.Dir.Dirty & Sta.Dir.Local & Sta.HomeProc.CacheState = CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.MemData := Sta.HomeProc.CacheData;
  NxtSta.HomeProc.CacheState := CACHE_S;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Data := Sta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE; dst : NODE do
rule "NI_Remote_Get_Nak"
  src != dst &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = dst & !Sta.UniMsg[src].HomeProc &
  Sta.Proc[dst].CacheState != CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  --undefine NxtSta.UniMsg[src].Proc;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.NakcMsg.Cmd := NAKC_Nakc;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset dst : NODE do
rule "NI_Remote_Get_Nak_Home"
  Sta.HomeUniMsg.Cmd = UNI_Get &
  Sta.HomeUniMsg.Proc = dst & !Sta.HomeUniMsg.HomeProc &
  Sta.Proc[dst].CacheState != CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.HomeUniMsg.Cmd := UNI_Nak;
  --undefine NxtSta.HomeUniMsg.Proc;
  undefine NxtSta.HomeUniMsg.Data;
  NxtSta.NakcMsg.Cmd := NAKC_Nakc;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE; dst : NODE do
rule "NI_Remote_Get_Put"
  src != dst &
  Sta.UniMsg[src].Cmd = UNI_Get &
  Sta.UniMsg[src].Proc = dst & !Sta.UniMsg[src].HomeProc &
  Sta.Proc[dst].CacheState = CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Proc[dst].CacheState := CACHE_S;
  NxtSta.UniMsg[src].Cmd := UNI_Put;
  NxtSta.UniMsg[src].Data := Sta.Proc[dst].CacheData;
  NxtSta.ShWbMsg.Cmd := SHWB_ShWb;
  NxtSta.ShWbMsg.Proc := src;
  NxtSta.ShWbMsg.HomeProc := false;
  NxtSta.ShWbMsg.Data := Sta.Proc[dst].CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset dst : NODE do
rule "NI_Remote_Get_Put_Home"
  Sta.HomeUniMsg.Cmd = UNI_Get &
  Sta.HomeUniMsg.Proc = dst & !Sta.HomeUniMsg.HomeProc &
  Sta.Proc[dst].CacheState = CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Proc[dst].CacheState := CACHE_S;
  NxtSta.HomeUniMsg.Cmd := UNI_Put;
  NxtSta.HomeUniMsg.Data := Sta.Proc[dst].CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_Nak"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  ( Sta.Dir.Pending |
    Sta.Dir.Dirty & Sta.Dir.Local & Sta.HomeProc.CacheState != CACHE_E |
    Sta.Dir.Dirty & !Sta.Dir.Local & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr)
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  --undefine NxtSta.UniMsg[src].Proc;
  undefine NxtSta.UniMsg[src].Data;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_GetX"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending & Sta.Dir.Dirty & !Sta.Dir.Local &
  (Sta.Dir.HeadPtr != src | Sta.Dir.HomeHeadPtr)
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.UniMsg[src].Cmd := UNI_GetX;
  NxtSta.UniMsg[src].Proc := Sta.Dir.HeadPtr;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.UniMsg[src].HomeProc := Sta.Dir.HomeHeadPtr;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_1"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & !Sta.Dir.HeadVld & Sta.Dir.Local & Sta.HomeProc.ProcCmd = NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
  NxtSta.HomeProc.InvMarked := true;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_2"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & !Sta.Dir.HeadVld & Sta.Dir.Local & Sta.HomeProc.ProcCmd != NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_3"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & !Sta.Dir.HeadVld & !Sta.Dir.Local
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_4"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr & !Sta.Dir.HomeShrSet &
  forall p : NODE do p != src -> !Sta.Dir.ShrSet[p] end &
  Sta.Dir.Local & Sta.HomeProc.ProcCmd = NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
  NxtSta.HomeProc.InvMarked := true;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_5"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr & !Sta.Dir.HomeShrSet &
  forall p : NODE do p != src -> !Sta.Dir.ShrSet[p] end &
  Sta.Dir.Local & Sta.HomeProc.ProcCmd != NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_6"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr & !Sta.Dir.HomeShrSet &
  forall p : NODE do p != src -> !Sta.Dir.ShrSet[p] end &
  !Sta.Dir.Local
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_7"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & (Sta.Dir.HeadPtr != src | Sta.Dir.HomeHeadPtr) &
  Sta.Dir.Local & Sta.HomeProc.ProcCmd != NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_7_NODE_Get"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & (Sta.Dir.HeadPtr != src | Sta.Dir.HomeHeadPtr) &
  Sta.Dir.Local & Sta.HomeProc.ProcCmd = NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
  NxtSta.HomeProc.InvMarked := true;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_8_Home"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr &
  Sta.Dir.HomeShrSet &
  Sta.Dir.Local & Sta.HomeProc.ProcCmd != NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_8_Home_NODE_Get"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr &
  Sta.Dir.HomeShrSet &
  Sta.Dir.Local & Sta.HomeProc.ProcCmd = NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
  NxtSta.HomeProc.InvMarked := true;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE; pp : NODE do
rule "NI_Local_GetX_PutX_8"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr &
  Sta.Dir.ShrSet[pp] &
  Sta.Dir.Local & Sta.HomeProc.ProcCmd != NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE; pp : NODE do
rule "NI_Local_GetX_PutX_8_NODE_Get"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr &
  Sta.Dir.ShrSet[pp] &
  Sta.Dir.Local & Sta.HomeProc.ProcCmd = NODE_Get
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
  NxtSta.HomeProc.InvMarked := true;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_9"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & (Sta.Dir.HeadPtr != src | Sta.Dir.HomeHeadPtr) &
  !Sta.Dir.Local
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_10_Home"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr &
  Sta.Dir.HomeShrSet &
  !Sta.Dir.Local
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE; pp : NODE do
rule "NI_Local_GetX_PutX_10"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  !Sta.Dir.Dirty & Sta.Dir.HeadVld & Sta.Dir.HeadPtr = src & !Sta.Dir.HomeHeadPtr &
  Sta.Dir.ShrSet[pp] &
  !Sta.Dir.Local
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Pending := true;
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    if ( p != src &
         ( Sta.Dir.ShrVld & Sta.Dir.ShrSet[p] |
           Sta.Dir.HeadVld & Sta.Dir.HeadPtr = p & !Sta.Dir.HomeHeadPtr) ) then
      NxtSta.Dir.InvSet[p] := true;
      NxtSta.InvMsg[p].Cmd := INV_Inv;
    else
      NxtSta.Dir.InvSet[p] := false;
      NxtSta.InvMsg[p].Cmd := INV_None;
    end;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.HomeInvMsg.Cmd := INV_None;

  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.MemData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_Local_GetX_PutX_11"
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].HomeProc &
  !Sta.Dir.Pending &
  Sta.Dir.Dirty & Sta.Dir.Local & Sta.HomeProc.CacheState = CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Dir.Local := false;
  NxtSta.Dir.Dirty := true;
  NxtSta.Dir.HeadVld := true;
  NxtSta.Dir.HeadPtr := src;
  NxtSta.Dir.HomeHeadPtr := false;
  NxtSta.Dir.ShrVld := false;
  for p : NODE do
    NxtSta.Dir.ShrSet[p] := false;
    NxtSta.Dir.InvSet[p] := false;
  end;
  NxtSta.Dir.HomeShrSet := false;
  NxtSta.Dir.HomeInvSet := false;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.HomeProc.CacheData;
  NxtSta.HomeProc.CacheState := CACHE_I;
  undefine NxtSta.HomeProc.CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE; dst : NODE do
rule "NI_Remote_GetX_Nak"
  src != dst &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = dst & !Sta.UniMsg[src].HomeProc &
  Sta.Proc[dst].CacheState != CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.UniMsg[src].Cmd := UNI_Nak;
  --undefine NxtSta.UniMsg[src].Proc;
  undefine NxtSta.UniMsg[src].Data;
  NxtSta.NakcMsg.Cmd := NAKC_Nakc;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset dst : NODE do
rule "NI_Remote_GetX_Nak_Home"
  Sta.HomeUniMsg.Cmd = UNI_GetX &
  Sta.HomeUniMsg.Proc = dst & !Sta.HomeUniMsg.HomeProc &
  Sta.Proc[dst].CacheState != CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.HomeUniMsg.Cmd := UNI_Nak;
  --undefine NxtSta.HomeUniMsg.Proc;
  undefine NxtSta.HomeUniMsg.Data;
  NxtSta.NakcMsg.Cmd := NAKC_Nakc;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE; dst : NODE do
rule "NI_Remote_GetX_PutX"
  src != dst &
  Sta.UniMsg[src].Cmd = UNI_GetX &
  Sta.UniMsg[src].Proc = dst & !Sta.UniMsg[src].HomeProc &
  Sta.Proc[dst].CacheState = CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  NxtSta.UniMsg[src].Cmd := UNI_PutX;
  --undefine NxtSta.UniMsg[src].Proc;
  NxtSta.UniMsg[src].Data := Sta.Proc[dst].CacheData;
  NxtSta.ShWbMsg.Cmd := SHWB_FAck;
  NxtSta.ShWbMsg.Proc := src;
  undefine NxtSta.ShWbMsg.Data;
  NxtSta.ShWbMsg.HomeProc := false;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset dst : NODE do
rule "NI_Remote_GetX_PutX_Home"
  Sta.HomeUniMsg.Cmd = UNI_GetX &
  Sta.HomeUniMsg.Proc = dst & !Sta.HomeUniMsg.HomeProc &
  Sta.Proc[dst].CacheState = CACHE_E
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  NxtSta.HomeUniMsg.Cmd := UNI_PutX;
  --undefine NxtSta.HomeUniMsg.Proc;
  NxtSta.HomeUniMsg.Data := Sta.Proc[dst].CacheData;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_Local_Put"
  Sta.HomeUniMsg.Cmd = UNI_Put
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.HomeUniMsg.Cmd := UNI_None;
  undefine NxtSta.HomeUniMsg.Proc;
  undefine NxtSta.HomeUniMsg.Data;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.Local := true;
  NxtSta.MemData := Sta.HomeUniMsg.Data;
  NxtSta.HomeProc.ProcCmd := NODE_None;
  if (Sta.HomeProc.InvMarked) then
    NxtSta.HomeProc.InvMarked := false;
    NxtSta.HomeProc.CacheState := CACHE_I;
	undefine NxtSta.HomeProc.CacheData;
  else
    NxtSta.HomeProc.CacheState := CACHE_S;
    NxtSta.HomeProc.CacheData := Sta.HomeUniMsg.Data;
  end;
--
  Sta := NxtSta;
endrule;

ruleset dst : NODE do
rule "NI_Remote_Put"
  Sta.UniMsg[dst].Cmd = UNI_Put
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.UniMsg[dst].Cmd := UNI_None;
  undefine NxtSta.UniMsg[dst].Proc;
  undefine NxtSta.UniMsg[dst].Data;
  NxtSta.Proc[dst].ProcCmd := NODE_None;
  if (Sta.Proc[dst].InvMarked) then
    NxtSta.Proc[dst].InvMarked := false;
    NxtSta.Proc[dst].CacheState := CACHE_I;
	undefine NxtSta.Proc[dst].CacheData;
  else
    NxtSta.Proc[dst].CacheState := CACHE_S;
    NxtSta.Proc[dst].CacheData := Sta.UniMsg[dst].Data;
  end;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_Local_PutXAcksDone"
  Sta.HomeUniMsg.Cmd = UNI_PutX
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.HomeUniMsg.Cmd := UNI_None;
  undefine NxtSta.HomeUniMsg.Proc;
  undefine NxtSta.HomeUniMsg.Data;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Local := true;
  NxtSta.Dir.HeadVld := false;
  undefine NxtSta.Dir.HeadPtr;
  NxtSta.HomeProc.ProcCmd := NODE_None;
  NxtSta.HomeProc.InvMarked := false;
  NxtSta.HomeProc.CacheState := CACHE_E;
  NxtSta.HomeProc.CacheData := Sta.HomeUniMsg.Data;
--
  Sta := NxtSta;
endrule;

ruleset dst : NODE do
rule "NI_Remote_PutX"
  Sta.UniMsg[dst].Cmd = UNI_PutX &
  Sta.Proc[dst].ProcCmd = NODE_GetX
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.UniMsg[dst].Cmd := UNI_None;
  undefine NxtSta.UniMsg[dst].Proc;
  undefine NxtSta.UniMsg[dst].Data;
  NxtSta.Proc[dst].ProcCmd := NODE_None;
  NxtSta.Proc[dst].InvMarked := false;
  NxtSta.Proc[dst].CacheState := CACHE_E;
  NxtSta.Proc[dst].CacheData := Sta.UniMsg[dst].Data;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset dst : NODE do
rule "NI_Inv"
  Sta.InvMsg[dst].Cmd = INV_Inv
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.InvMsg[dst].Cmd := INV_InvAck;
  NxtSta.Proc[dst].CacheState := CACHE_I;
  undefine NxtSta.Proc[dst].CacheData;
  if (Sta.Proc[dst].ProcCmd = NODE_Get) then
    NxtSta.Proc[dst].InvMarked := true;
  end;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_InvAck_exists_Home"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending & Sta.Dir.InvSet[src] &
  Sta.Dir.HomeInvSet
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE; pp : NODE do
rule "NI_InvAck_exists"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending & Sta.Dir.InvSet[src] &
  (pp != src & Sta.Dir.InvSet[pp])
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_InvAck_1"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending & Sta.Dir.InvSet[src] &
  Sta.Dir.Local & !Sta.Dir.Dirty &
  !Sta.Dir.HomeInvSet & forall p : NODE do p = src | !Sta.Dir.InvSet[p] end
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Local := false;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_InvAck_2"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending & Sta.Dir.InvSet[src] &
  !Sta.Dir.Local &
  !Sta.Dir.HomeInvSet & forall p : NODE do p = src | !Sta.Dir.InvSet[p] end
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
  NxtSta.Dir.Pending := false;
--
  Sta := NxtSta;
endrule;
endruleset;

ruleset src : NODE do
rule "NI_InvAck_3"
  Sta.InvMsg[src].Cmd = INV_InvAck &
  Sta.Dir.Pending & Sta.Dir.InvSet[src] &
  Sta.Dir.Dirty &
  !Sta.Dir.HomeInvSet & forall p : NODE do p = src | !Sta.Dir.InvSet[p] end
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.InvMsg[src].Cmd := INV_None;
  NxtSta.Dir.InvSet[src] := false;
  NxtSta.Dir.Pending := false;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_Wb"
  Sta.WbMsg.Cmd = WB_Wb
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.WbMsg.Cmd := WB_None;
  undefine NxtSta.WbMsg.Proc;
  undefine NxtSta.WbMsg.Data;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.HeadVld := false;
  undefine NxtSta.Dir.HeadPtr;
  NxtSta.MemData := Sta.WbMsg.Data;
--
  Sta := NxtSta;
endrule;

rule "NI_FAck"
  Sta.ShWbMsg.Cmd = SHWB_FAck
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.ShWbMsg.Cmd := SHWB_None;
  undefine NxtSta.ShWbMsg.Proc;
  undefine NxtSta.ShWbMsg.Data;
  NxtSta.Dir.Pending := false;
  if (Sta.Dir.Dirty) then
    NxtSta.Dir.HeadPtr := Sta.ShWbMsg.Proc;
    NxtSta.Dir.HomeHeadPtr := Sta.ShWbMsg.HomeProc;
  end;
--
  Sta := NxtSta;
endrule;

rule "NI_ShWb"
  Sta.ShWbMsg.Cmd = SHWB_ShWb
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.ShWbMsg.Cmd := SHWB_None;
  undefine NxtSta.ShWbMsg.Proc;
  undefine NxtSta.ShWbMsg.Data;
  NxtSta.Dir.Pending := false;
  NxtSta.Dir.Dirty := false;
  NxtSta.Dir.ShrVld := true;
  for p : NODE do
    if (p = Sta.ShWbMsg.Proc & !Sta.ShWbMsg.HomeProc) | Sta.Dir.ShrSet[p] then
      NxtSta.Dir.ShrSet[p] := true;
      NxtSta.Dir.InvSet[p] := true;
    else
      NxtSta.Dir.ShrSet[p] := false;
      NxtSta.Dir.InvSet[p] := false;
    end;
  end;
  if (Sta.ShWbMsg.HomeProc | Sta.Dir.HomeShrSet) then
    NxtSta.Dir.HomeShrSet := true;
    NxtSta.Dir.HomeInvSet := true;
  else
    NxtSta.Dir.HomeShrSet := false;
    NxtSta.Dir.HomeInvSet := false;
  end;
  NxtSta.MemData := Sta.ShWbMsg.Data;
--
  Sta := NxtSta;
endrule;

ruleset src : NODE do
rule "NI_Replace"
  Sta.RpMsg[src].Cmd = RP_Replace
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.RpMsg[src].Cmd := RP_None;
  if (Sta.Dir.ShrVld) then
    NxtSta.Dir.ShrSet[src] := false;
    NxtSta.Dir.InvSet[src] := false;
  end;
--
  Sta := NxtSta;
endrule;
endruleset;

rule "NI_Replace_Home"
  Sta.HomeRpMsg.Cmd = RP_Replace
==>
var NxtSta : STATE;
begin
  NxtSta := Sta;
--
  NxtSta.HomeRpMsg.Cmd := RP_None;
  if (Sta.Dir.ShrVld) then
    NxtSta.Dir.HomeShrSet := false;
    NxtSta.Dir.HomeInvSet := false;
  end;
--
  Sta := NxtSta;
endrule;

invariant "inv104"
  forall p : NODE do forall q : NODE do
    p != q ->
    !((Sta.Dir.InvSet[p] = TRUE) & (Sta.Proc[q].CacheState = CACHE_E) & (Sta.UniMsg[q].Cmd = UNI_Get))
  end end;
  
invariant "inv120"
  forall p : NODE do forall q : NODE do
    p != q ->
    !((Sta.UniMsg[p].Cmd = UNI_Get) & (Sta.Proc[q].CacheState = CACHE_E) & (Sta.UniMsg[q].Cmd = UNI_GetX))
  end end;
  
invariant "inv121"
  forall p : NODE do forall q : NODE do
    p != q ->
    !((Sta.UniMsg[p].Cmd = UNI_Get) & (Sta.Proc[q].CacheState = CACHE_E) & (Sta.UniMsg[q].Cmd = UNI_Get))
  end end;
  
invariant "inv129"
  forall p : NODE do forall q : NODE do
    p != q ->
    !((Sta.UniMsg[p].Cmd = UNI_Get) & (Sta.UniMsg[q].HomeProc = FALSE) & (Sta.UniMsg[q].Proc = q))
  end end;
  
invariant "inv135"
  forall p : NODE do
  !((Sta.Dir.InvSet[p] = TRUE) & (Sta.Dir.HomeHeadPtr = TRUE))
  end;
  
invariant "inv136"
  forall p : NODE do forall q : NODE do
    p != q ->
    !((Sta.UniMsg[p].Cmd = UNI_GetX) & (Sta.Proc[q].CacheState = CACHE_E) & (Sta.UniMsg[q].Cmd = UNI_Get))
  end end;

invariant "inv150"
  forall p : NODE do forall q : NODE do
    p != q ->
    !((Sta.Dir.InvSet[p] = TRUE) & (Sta.Proc[q].CacheState = CACHE_E) & (Sta.UniMsg[q].Cmd = UNI_GetX))
  end end;
  
invariant "inv153"
  forall p : NODE do
  !((Sta.UniMsg[p].HomeProc = FALSE) & (Sta.UniMsg[p].Proc = p))
  end;
  
invariant "inv157"
  forall p : NODE do
  !((Sta.Dir.ShrSet[p] = TRUE) & (Sta.Dir.HomeHeadPtr = TRUE))
  end;  