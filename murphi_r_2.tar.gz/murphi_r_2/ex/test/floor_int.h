int floor_int(double x)
{
  return (int)floor(x);
}
