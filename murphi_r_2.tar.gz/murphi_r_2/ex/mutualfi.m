const clientNUMS : 2;
type state : enum{I, T, C, E};

     client: 1..clientNUMS;

var n : array [client] of state;

    x : boolean; 
    
ruleset i : client do
rule "Try" n[i] = I ==> begin
      n[i] := T;endrule; 

rule "Crit"
      n[i] = T& x = true ==>begin
      n[i] := C; x := false; endrule;

rule "Exit"
      n[i] = C ==>begin
      n[i] := E;endrule;
      
 
rule "Idle"
      n[i] = E ==> begin n[i] := I;
      x := true;endrule;
endruleset;

startstate
begin
 for i: client do
    n[i] := I; 
  endfor;
  x := true;
endstartstate;

ruleset i:client; j: client do
invariant "coherence"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence2"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence3"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence4"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence5"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence6"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence7"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence8"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence9"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence10"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence11"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence12"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence13"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence14"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence15"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence16"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence17"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence18"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence19"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence20"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence21"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence22"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence23"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence24"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence25"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence26"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence27"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence28"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence29"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence30"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence31"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence32"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence33"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence34"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence35"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence36"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence37"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence38"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence39"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence40"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence41"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence42"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence43"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence44"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence45"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence46"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence47"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence48"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence49"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence50"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence51"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence52"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence53"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence54"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence55"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence56"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence57"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence58"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence59"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence60"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence61"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence62"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence63"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence64"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence65"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence66"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence67"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence68"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence69"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence70"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence71"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence72"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence73"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence74"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence75"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence76"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence77"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence78"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence79"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence80"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence81"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence82"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence83"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence84"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence85"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence86"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence87"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence88"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

ruleset i:client; j: client do
invariant "coherence89"
  i != j -> (n[i] = C -> n[j] != C);
endruleset;

