#coding=utf-8

"""
This package is for checking invariant with NuSMV in subprocess

@author Yongjian Li <lyj238@gmail.com>
@author Kaiqiang Duan <duankq@ios.ac.cn>
"""

from smv import SMV

