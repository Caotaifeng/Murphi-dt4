#coding=utf-8

"""
This package is for checking z3 formula with python

@author Yongjian Li <lyj238@gmail.com>
@author Kaiqiang Duan <duankq@ios.ac.cn>
"""

from smt2 import SMT2
