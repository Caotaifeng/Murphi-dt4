#coding=utf-8

HOST = ''
PORT = 50008

# maximum sleep time while there is no connect for a smv process
MAX_SLEEP_TIME = 5

# time out in seconds
TIME_OUT = 5
MU_CHECK_TIMEOUT = 600
MU_CHECK_MEMORY = 1024

# path to NuSMV
SMV_PATH = '/home/ctf/201808/paraverif/NuSMV/NuSMV-2.6.0-Linux/bin/NuSMV'
MU_PATH = '/home/ctf/201905/murphi_r_2/src/mu'
MU_INCLUDE = '/home/ctf/201905/murphi_r_2/include'
GXX_PATH = '/usr/bin/g++'

# path for storing smv files
SMV_FILE_DIR = '/home/ctf/201808/paraverif/smvstore/'
MU_FILE_DIR = '/home/ctf/201905/server-dt4/murphistore/'





dirs = [SMV_FILE_DIR, MU_FILE_DIR]

import os

for d in dirs:
    if not os.path.isdir(d):
        os.makedirs(d)
